"""Entry point for python -m google_cli."""

from .cli.main import cli

if __name__ == "__main__":
    cli()
