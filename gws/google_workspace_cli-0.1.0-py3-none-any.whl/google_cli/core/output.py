"""Output formatting utilities for the CLI."""

import csv
import io
import json
import sys
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.table import Table


class OutputFormat(str, Enum):
    """Output format options."""

    JSON = "json"
    TEXT = "text"
    TABLE = "table"
    YAML = "yaml"
    CSV = "csv"


def output_json(
    data: Any,
    status: str = "success",
    metadata: Optional[Dict[str, Any]] = None,
    file=sys.stdout,
) -> str:
    """
    Output data in JSON format.

    Args:
        data: Data to output
        status: Status (success/error)
        metadata: Optional metadata to include
        file: Output file (default: stdout)

    Returns:
        JSON string
    """
    output = {"status": status, "data": data}

    if metadata:
        output["metadata"] = metadata
    else:
        output["metadata"] = {"timestamp": datetime.utcnow().isoformat() + "Z"}

    json_str = json.dumps(output, indent=2, ensure_ascii=False, default=str)
    print(json_str, file=file)
    return json_str


def output_error(
    error: Exception,
    code: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    file=sys.stderr,
) -> str:
    """
    Output error in JSON format to stderr.

    Args:
        error: Exception object
        code: HTTP-style error code
        details: Additional error details
        file: Output file (default: stderr)

    Returns:
        JSON error string
    """
    error_data = {
        "status": "error",
        "error": {
            "type": type(error).__name__,
            "message": str(error),
            "code": code,
        },
        "metadata": {"timestamp": datetime.utcnow().isoformat() + "Z"},
    }

    if details:
        error_data["error"]["details"] = details

    json_str = json.dumps(error_data, indent=2, ensure_ascii=False)
    print(json_str, file=file)
    return json_str


def output_text(
    message: str,
    data: Optional[Dict[str, Any]] = None,
    success: bool = True,
    file=sys.stdout,
) -> None:
    """
    Output human-readable text format.

    Args:
        message: Main message to display
        data: Optional key-value data to display
        success: Whether this is a success message
        file: Output file (default: stdout)
    """
    symbol = "✓" if success else "✗"
    print(f"{symbol} {message}", file=file)

    if data:
        print(file=file)
        for key, value in data.items():
            # Format key as title case with spaces
            display_key = key.replace("_", " ").title()
            print(f"  {display_key}: {value}", file=file)


def output_table(
    data: List[Dict[str, Any]],
    columns: Optional[List[str]] = None,
    title: Optional[str] = None,
) -> None:
    """
    Output data in table format using Rich.

    Args:
        data: List of dictionaries to display
        columns: Column names (if None, uses keys from first item)
        title: Optional table title
    """
    if not data:
        print("No data to display")
        return

    # Determine columns
    if columns is None:
        columns = list(data[0].keys())

    # Create table
    console = Console()
    table = Table(title=title, show_header=True, header_style="bold magenta")

    # Add columns
    for col in columns:
        table.add_column(col.replace("_", " ").title())

    # Add rows
    for item in data:
        row = []
        for col in columns:
            value = item.get(col, "")
            # Truncate long values
            value_str = str(value)
            if len(value_str) > 50:
                value_str = value_str[:47] + "..."
            row.append(value_str)
        table.add_row(*row)

    console.print(table)


def format_file_size(size_bytes: Optional[int]) -> str:
    """
    Format file size in human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted size string (e.g., "2.4 MB")
    """
    if size_bytes is None or size_bytes == 0:
        return "0 B"

    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(size_bytes)
    unit_index = 0

    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1

    return f"{size:.1f} {units[unit_index]}"


def format_datetime(dt: Optional[datetime]) -> str:
    """
    Format datetime in ISO 8601 format.

    Args:
        dt: Datetime object

    Returns:
        ISO 8601 formatted string
    """
    if dt is None:
        return "N/A"
    return dt.isoformat()


def truncate_string(text: str, max_length: int = 50) -> str:
    """
    Truncate string to max length with ellipsis.

    Args:
        text: Text to truncate
        max_length: Maximum length

    Returns:
        Truncated string
    """
    if len(text) <= max_length:
        return text
    return text[: max_length - 3] + "..."


def output_yaml(data: Any, file=sys.stdout) -> str:
    """
    Output data in YAML format.

    Args:
        data: Data to output
        file: Output file (default: stdout)

    Returns:
        YAML string
    """
    try:
        import yaml
        yaml_str = yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False)
        print(yaml_str, file=file)
        return yaml_str
    except ImportError:
        # Fallback to JSON if PyYAML not installed
        print("# PyYAML not installed, falling back to JSON format", file=file)
        return output_json(data, file=file)


def output_csv(
    data: List[Dict[str, Any]],
    columns: Optional[List[str]] = None,
    file=sys.stdout
) -> str:
    """
    Output data in CSV format.

    Args:
        data: List of dictionaries to output
        columns: Column names (if None, uses keys from first item)
        file: Output file (default: stdout)

    Returns:
        CSV string
    """
    if not data:
        return ""

    # Determine columns
    if columns is None:
        columns = list(data[0].keys())

    # Write CSV
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns, extrasaction='ignore')
    writer.writeheader()

    for item in data:
        # Convert all values to strings
        row = {k: str(v) if v is not None else "" for k, v in item.items()}
        writer.writerow(row)

    csv_str = output.getvalue()
    print(csv_str, file=file, end='')
    return csv_str


def output_ndjson(data: List[Dict[str, Any]], file=sys.stdout) -> None:
    """
    Output data in NDJSON (newline-delimited JSON) format.
    Used for streaming/pagination results.

    Args:
        data: List of dictionaries to output
        file: Output file (default: stdout)
    """
    for item in data:
        json_str = json.dumps(item, ensure_ascii=False, default=str)
        print(json_str, file=file)
