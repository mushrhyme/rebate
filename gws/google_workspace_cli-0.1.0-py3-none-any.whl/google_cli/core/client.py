"""Base client for Google Workspace API services."""

import os
from typing import Any, List, Optional

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import Resource, build
from googleapiclient.errors import HttpError

from ..auth.credentials import CredentialsManager
from .errors import handle_google_api_error


class BaseClient:
    """
    Base client for Google Workspace API services.

    Provides common functionality for authentication and API service building.
    """

    def __init__(
        self,
        service_name: str,
        version: str,
        credentials_path: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ):
        """
        Initialize base client.

        Args:
            service_name: Google API service name (e.g., 'drive', 'gmail')
            version: API version (e.g., 'v3', 'v1')
            credentials_path: Path to credentials.json
            scopes: OAuth scopes required for this service
        """
        self.service_name = service_name
        self.version = version
        self.scopes = scopes or []

        # Initialize credentials manager
        self.credentials_manager = CredentialsManager(
            credentials_path=credentials_path, scopes=self.scopes
        )

        # Pre-supplied credentials (remote/multi-user track). When set, the
        # service is built from these directly, bypassing local token files.
        self._injected_creds: Optional[Credentials] = None

        # Service will be built on first use
        self._service: Optional[Resource] = None

    def set_credentials(self, creds: Credentials) -> "BaseClient":
        """Inject already-obtained credentials and force the API service to
        rebuild.

        Returns self to allow ``DriveService().set_credentials(creds)``.
        """
        self._injected_creds = creds
        self._service = None
        return self

    @property
    def service(self) -> Resource:
        """
        Get or build Google API service.

        Returns:
            Google API service resource

        Raises:
            GoogleAuthError: If authentication fails
        """
        if self._service is None:
            try:
                creds = self._injected_creds or self.credentials_manager.authenticate()

                # Attach the quota/billing project so every request carries the
                # `x-goog-user-project` header (matches the official CLI). This
                # gives project-bound APIs (e.g. Apps Script) a project context;
                # without it some calls return 403 "cannot access resource".
                quota_project = self._get_quota_project()
                if quota_project and hasattr(creds, "with_quota_project"):
                    creds = creds.with_quota_project(quota_project)

                self._service = build(self.service_name, self.version, credentials=creds)
            except Exception as e:
                raise handle_google_api_error(e)

        return self._service

    def _get_quota_project(self) -> Optional[str]:
        """Resolve the project for the ``x-goog-user-project`` header.

        Opt-in via the ``GOOGLE_WORKSPACE_PROJECT_ID`` environment variable.

        We deliberately do NOT fall back to the ``project_id`` inside
        credentials.json: that project may be one the signed-in user has no
        ``serviceusage.services.use`` permission on, in which case sending the
        header makes every call fail with 403. Setting the header is only safe
        for a project the caller controls, so it must be chosen explicitly.
        """
        return os.environ.get("GOOGLE_WORKSPACE_PROJECT_ID") or None

    def execute_api_call(self, api_call: Any) -> Any:
        """
        Execute Google API call with error handling.

        Args:
            api_call: Google API method call (e.g., service.files().list())

        Returns:
            API response

        Raises:
            GoogleAPIError: If API call fails
        """
        try:
            return api_call.execute()
        except HttpError as e:
            raise handle_google_api_error(e)
        except Exception as e:
            raise handle_google_api_error(e)

    def refresh_service(self) -> None:
        """Force service refresh (useful after credential updates)."""
        self._service = None

    # ------------------------------------------------------------------
    # Generic API passthrough
    #
    # The curated service methods cover the common 80%. These three helpers
    # expose the *entire* official API surface for the bound service by
    # traversing the discovery document directly — so anything Google ships
    # is callable without a hand-written wrapper.
    # ------------------------------------------------------------------
    def _root_desc(self) -> dict:
        """Discovery document for the bound service (built lazily)."""
        return getattr(self.service, "_rootDesc", {}) or {}

    def call_api(self, method_path: str, **params: Any) -> Any:
        """Call any method of this service's API by its dotted resource path.

        Args:
            method_path: Dotted path of resource collections ending in a method,
                e.g. ``"spreadsheets.values.get"`` or ``"users.messages.send"``.
                Slashes are accepted as separators too.
            **params: Keyword arguments for the method — path/query params and an
                optional ``body`` dict for the request payload.

        Returns:
            The raw API response (already executed with error handling).

        Raises:
            GoogleAPIError: If the path is unknown or the call fails.
        """
        parts = [p for p in method_path.replace("/", ".").split(".") if p]
        if not parts:
            raise handle_google_api_error(ValueError("Empty API method path"))

        obj: Any = self.service
        try:
            for part in parts[:-1]:
                obj = getattr(obj, part)()  # descend into a sub-resource
            method = getattr(obj, parts[-1])
        except AttributeError:
            available = ", ".join(self.discover_methods()[:20])
            raise handle_google_api_error(
                ValueError(
                    f"Unknown API method '{method_path}' for "
                    f"{self.service_name} {self.version}. "
                    f"Examples: {available} ... (use list to see all)"
                )
            )

        return self.execute_api_call(method(**params))

    def discover_methods(self) -> List[str]:
        """List every callable method path in this service's discovery doc."""
        paths: List[str] = []

        def walk(node: dict, prefix: str) -> None:
            for mname in (node.get("methods") or {}):
                paths.append(f"{prefix}{mname}")
            for rname, rnode in (node.get("resources") or {}).items():
                walk(rnode, f"{prefix}{rname}.")

        walk(self._root_desc(), "")
        return sorted(paths)

    def describe_method(self, method_path: str) -> dict:
        """Return the discovery-doc schema for a single method path."""
        parts = [p for p in method_path.replace("/", ".").split(".") if p]
        node = self._root_desc()
        for part in parts[:-1]:
            node = (node.get("resources") or {}).get(part, {})
        method = (node.get("methods") or {}).get(parts[-1] if parts else "")
        if not method:
            raise handle_google_api_error(
                ValueError(f"Unknown API method '{method_path}'")
            )
        return {
            "id": method.get("id"),
            "httpMethod": method.get("httpMethod"),
            "path": method.get("path"),
            "description": method.get("description"),
            "parameters": method.get("parameters", {}),
            "request": method.get("request"),
            "response": method.get("response"),
            "scopes": method.get("scopes"),
        }

    def get_credentials(self) -> Credentials:
        """Get current credentials."""
        return self.credentials_manager.get_credentials()

    def paginate_all(
        self,
        api_call,
        page_token_field: str = "pageToken",
        next_token_field: str = "nextPageToken",
        items_field: str = "items",
        max_pages: int = 10,
        page_delay_ms: int = 100
    ) -> List[Any]:
        """
        Auto-paginate through API results (GWS-style helper).

        Args:
            api_call: Base API call (should accept pageToken parameter)
            page_token_field: Name of page token parameter
            next_token_field: Name of next page token in response
            items_field: Name of items list in response
            max_pages: Maximum pages to fetch
            page_delay_ms: Delay between pages in milliseconds

        Returns:
            List of all items across pages
        """
        import time

        all_items = []
        page_token = None
        pages_fetched = 0

        while pages_fetched < max_pages:
            # Build API call with page token
            params = {}
            if page_token:
                params[page_token_field] = page_token

            # Execute call
            try:
                response = self.execute_api_call(api_call(**params))
            except Exception:
                break

            # Extract items
            items = response.get(items_field, [])
            all_items.extend(items)

            # Check for next page
            page_token = response.get(next_token_field)
            if not page_token:
                break

            pages_fetched += 1

            # Delay before next page
            if page_delay_ms > 0 and page_token:
                time.sleep(page_delay_ms / 1000.0)

        return all_items
