"""Custom exceptions for Google Workspace CLI."""

from typing import Any, Dict, Optional


class GoogleAPIError(Exception):
    """Base exception for Google API errors."""

    def __init__(
        self,
        message: str,
        code: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}
        self.original_error = original_error

    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for JSON output."""
        return {
            "error": self.__class__.__name__,
            "message": self.message,
            "code": self.code,
            "details": self.details,
        }


class GoogleAuthError(GoogleAPIError):
    """Authentication or authorization error."""

    pass


class GoogleNotFoundError(GoogleAPIError):
    """Resource not found error."""

    def __init__(self, resource_type: str, resource_id: str):
        super().__init__(
            message=f"{resource_type} not found: {resource_id}",
            code=404,
            details={"resource_type": resource_type, "resource_id": resource_id},
        )


class GooglePermissionError(GoogleAPIError):
    """Permission denied error."""

    def __init__(self, resource: str, action: str):
        super().__init__(
            message=f"Permission denied: cannot {action} {resource}",
            code=403,
            details={"resource": resource, "action": action},
        )


class GoogleQuotaError(GoogleAPIError):
    """API quota exceeded error."""

    def __init__(self, service: str, limit: Optional[str] = None):
        message = f"Quota exceeded for {service}"
        if limit:
            message += f": {limit}"
        super().__init__(message=message, code=429, details={"service": service, "limit": limit})


class GoogleRateLimitError(GoogleAPIError):
    """Rate limit exceeded error."""

    def __init__(self, retry_after: Optional[int] = None):
        message = "Rate limit exceeded"
        if retry_after:
            message += f". Retry after {retry_after} seconds"
        super().__init__(
            message=message, code=429, details={"retry_after": retry_after} if retry_after else {}
        )


def handle_google_api_error(error: Exception) -> GoogleAPIError:
    """
    Convert Google API client errors to custom exceptions.

    Args:
        error: Original exception from Google API client

    Returns:
        Appropriate GoogleAPIError subclass
    """
    error_str = str(error).lower()

    # Check for specific error types
    if "not found" in error_str or "404" in error_str:
        return GoogleAPIError(str(error), code=404, original_error=error)

    if "permission" in error_str or "forbidden" in error_str or "403" in error_str:
        return GooglePermissionError("resource", "access")

    if "quota" in error_str or "429" in error_str:
        return GoogleQuotaError("API")

    if "unauthorized" in error_str or "401" in error_str:
        return GoogleAuthError(str(error), code=401, original_error=error)

    # Default to generic error
    return GoogleAPIError(str(error), original_error=error)
