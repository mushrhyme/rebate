"""Google Workspace CLI - Unified interface for Google Workspace APIs."""

__version__ = "0.1.0"
