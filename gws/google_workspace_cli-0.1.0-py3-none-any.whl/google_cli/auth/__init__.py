"""Authentication module for Google Workspace APIs."""

from .credentials import CredentialsManager
from .scopes import ServiceScopes

__all__ = ["CredentialsManager", "ServiceScopes"]
