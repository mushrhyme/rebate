"""Token storage backend for Google Workspace credentials.

``LocalPickleStore`` keeps a single user's OAuth token in a local pickle file
(``token.pickle``) for the CLI. ``TokenStore`` is the abstract base it
implements, kept pluggable for future backends.
"""

import os
import pickle
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from google.oauth2.credentials import Credentials


class TokenStore(ABC):
    """Abstract persistence for a user's OAuth credentials."""

    @abstractmethod
    def load(self, user_id: Optional[str] = None) -> Optional[Credentials]:
        """Return stored credentials for ``user_id`` or ``None`` if absent."""

    @abstractmethod
    def save(self, creds: Credentials, user_id: Optional[str] = None) -> None:
        """Persist ``creds`` for ``user_id``."""

    @abstractmethod
    def delete(self, user_id: Optional[str] = None) -> bool:
        """Remove stored credentials. Returns True if something was deleted."""


class LocalPickleStore(TokenStore):
    """Single-user pickle file on disk (CLI / dev track).

    ``user_id`` is ignored — there is exactly one local user.
    """

    def __init__(self, token_path: Path):
        self.token_path = Path(token_path)

    def load(self, user_id: Optional[str] = None) -> Optional[Credentials]:
        if not self.token_path.exists():
            return None
        try:
            with open(self.token_path, "rb") as fh:
                return pickle.load(fh)
        except Exception:
            return None

    def save(self, creds: Credentials, user_id: Optional[str] = None) -> None:
        self.token_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.token_path, "wb") as fh:
            pickle.dump(creds, fh)
        try:
            os.chmod(self.token_path, 0o600)
        except OSError:
            pass

    def delete(self, user_id: Optional[str] = None) -> bool:
        if self.token_path.exists():
            self.token_path.unlink()
            return True
        return False
