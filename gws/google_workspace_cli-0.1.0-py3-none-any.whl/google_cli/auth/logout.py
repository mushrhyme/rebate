"""Logout and token management utilities."""

import os
from pathlib import Path
from typing import Optional


def logout(
    delete_credentials: bool = False,
    token_path: Optional[str] = None,
    credentials_path: Optional[str] = None,
) -> dict:
    """
    Logout by deleting authentication tokens.

    Args:
        delete_credentials: If True, also delete credentials.json
        token_path: Custom token path
        credentials_path: Custom credentials path

    Returns:
        Dictionary with deleted files info
    """
    result = {"deleted": [], "not_found": [], "errors": []}

    # Resolve token path
    if token_path:
        token_file = Path(token_path).expanduser().resolve()
    else:
        # Try common locations
        token_locations = [
            Path.home() / ".google-cli" / "token.pickle",
            Path("token.pickle"),
        ]
        token_file = None
        for loc in token_locations:
            if loc.exists():
                token_file = loc
                break

    # Delete token file
    if token_file and token_file.exists():
        try:
            token_file.unlink()
            result["deleted"].append(str(token_file))
        except Exception as e:
            result["errors"].append(f"Failed to delete {token_file}: {str(e)}")
    elif token_file:
        result["not_found"].append(str(token_file))
    else:
        result["not_found"].append("token.pickle (searched in common locations)")

    # Delete credentials if requested
    if delete_credentials:
        if credentials_path:
            cred_file = Path(credentials_path).expanduser().resolve()
        else:
            # Try common locations
            cred_locations = [
                Path.home() / ".google-cli" / "credentials.json",
                Path("credentials.json"),
            ]
            cred_file = None
            for loc in cred_locations:
                if loc.exists():
                    cred_file = loc
                    break

        if cred_file and cred_file.exists():
            try:
                cred_file.unlink()
                result["deleted"].append(str(cred_file))
            except Exception as e:
                result["errors"].append(f"Failed to delete {cred_file}: {str(e)}")
        elif cred_file:
            result["not_found"].append(str(cred_file))

    return result


def revoke_credentials(credentials_path: Optional[str] = None) -> bool:
    """
    Revoke credentials with Google (requires valid token).

    Args:
        credentials_path: Path to credentials.json

    Returns:
        True if successful, False otherwise
    """
    try:
        from ..auth.credentials import CredentialsManager

        manager = CredentialsManager(credentials_path=credentials_path)
        manager.revoke()
        return True
    except Exception as e:
        print(f"Failed to revoke credentials: {e}")
        return False


def get_token_info(token_path: Optional[str] = None) -> dict:
    """
    Get information about current authentication token.

    Args:
        token_path: Custom token path

    Returns:
        Token information dictionary
    """
    try:
        from ..auth.credentials import CredentialsManager

        manager = CredentialsManager(token_path=token_path)

        # Load existing token
        if manager.token_path.exists():
            import pickle
            with open(manager.token_path, "rb") as f:
                creds = pickle.load(f)

            info = {
                "token_exists": True,
                "token_path": str(manager.token_path),
                "credentials_path": str(manager.credentials_path),
                "valid": creds.valid if creds else False,
                "expired": creds.expired if hasattr(creds, "expired") else None,
            }

            if hasattr(creds, "expiry") and creds.expiry:
                info["expiry"] = creds.expiry.isoformat()

            if hasattr(creds, "scopes"):
                info["scopes"] = creds.scopes

            return info
        else:
            return {
                "token_exists": False,
                "token_path": str(manager.token_path),
                "credentials_path": str(manager.credentials_path),
            }
    except Exception as e:
        return {"error": str(e)}
