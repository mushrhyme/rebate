"""Google Workspace API scope definitions."""

from enum import Enum
from typing import List


class ServiceScopes(str, Enum):
    """Standard scopes for Google Workspace services."""

    # Drive scopes
    DRIVE_READONLY = "https://www.googleapis.com/auth/drive.readonly"
    DRIVE = "https://www.googleapis.com/auth/drive"
    DRIVE_FILE = "https://www.googleapis.com/auth/drive.file"
    DRIVE_METADATA = "https://www.googleapis.com/auth/drive.metadata.readonly"

    # Gmail scopes
    GMAIL_READONLY = "https://www.googleapis.com/auth/gmail.readonly"
    GMAIL_SEND = "https://www.googleapis.com/auth/gmail.send"
    GMAIL_MODIFY = "https://www.googleapis.com/auth/gmail.modify"
    # Full Gmail access. NOTE: "https://www.googleapis.com/auth/gmail" is NOT a
    # valid scope — the full-access scope is the mail.google.com URL.
    GMAIL = "https://mail.google.com/"
    GMAIL_LABELS = "https://www.googleapis.com/auth/gmail.labels"

    # Sheets scopes
    SHEETS_READONLY = "https://www.googleapis.com/auth/spreadsheets.readonly"
    SHEETS = "https://www.googleapis.com/auth/spreadsheets"

    # Calendar scopes
    CALENDAR_READONLY = "https://www.googleapis.com/auth/calendar.readonly"
    CALENDAR_EVENTS = "https://www.googleapis.com/auth/calendar.events"
    CALENDAR = "https://www.googleapis.com/auth/calendar"

    # Docs scopes
    DOCS_READONLY = "https://www.googleapis.com/auth/documents.readonly"
    DOCS = "https://www.googleapis.com/auth/documents"

    # Chat scopes. NOTE: chat.bot is for Chat *apps* (service account) and
    # CANNOT be granted via interactive user consent. User-OAuth flows must use
    # chat.messages / chat.spaces instead.
    #
    # chat.messages       → send/read messages in spaces the user belongs to.
    # chat.spaces.readonly → list spaces and resolve DM spaces
    #                        (spaces.list / spaces.findDirectMessage). Required
    #                        for "list my spaces" and "DM me" — chat.messages
    #                        alone returns 403 insufficient scopes for those.
    CHAT_BOT = "https://www.googleapis.com/auth/chat.bot"
    CHAT_MESSAGES = "https://www.googleapis.com/auth/chat.messages"
    CHAT_SPACES = "https://www.googleapis.com/auth/chat.spaces"
    CHAT_SPACES_READONLY = "https://www.googleapis.com/auth/chat.spaces.readonly"

    # Apps Script scopes
    SCRIPT_PROJECTS = "https://www.googleapis.com/auth/script.projects"
    SCRIPT_PROCESSES = "https://www.googleapis.com/auth/script.processes"
    SCRIPT_DEPLOYMENTS = "https://www.googleapis.com/auth/script.deployments"

    # Tasks scopes
    TASKS_READONLY = "https://www.googleapis.com/auth/tasks.readonly"
    TASKS = "https://www.googleapis.com/auth/tasks"

    # Slides scopes
    SLIDES_READONLY = "https://www.googleapis.com/auth/presentations.readonly"
    SLIDES = "https://www.googleapis.com/auth/presentations"

    # Forms scopes
    FORMS_BODY = "https://www.googleapis.com/auth/forms.body"
    FORMS_RESPONSES_READONLY = (
        "https://www.googleapis.com/auth/forms.responses.readonly"
    )

    # People (Contacts) scopes
    CONTACTS_READONLY = "https://www.googleapis.com/auth/contacts.readonly"
    CONTACTS = "https://www.googleapis.com/auth/contacts"

    # Meet scopes
    MEET_READONLY = "https://www.googleapis.com/auth/meetings.space.readonly"
    MEET_CREATED = "https://www.googleapis.com/auth/meetings.space.created"

    # Classroom scopes
    CLASSROOM_COURSES = "https://www.googleapis.com/auth/classroom.courses"
    CLASSROOM_ROSTERS = "https://www.googleapis.com/auth/classroom.rosters"

    # Keep scopes
    KEEP_READONLY = "https://www.googleapis.com/auth/keep.readonly"
    KEEP = "https://www.googleapis.com/auth/keep"


def get_service_scopes(service: str, readonly: bool = False) -> List[str]:
    """
    Get recommended scopes for a service.

    A service may need more than one scope (e.g. Chat needs both
    ``chat.messages`` to send and ``chat.spaces.readonly`` to list/resolve
    spaces), so each entry is a list.

    Args:
        service: Service name (drive, gmail, sheets, etc.)
        readonly: If True, request minimal readonly scopes

    Returns:
        List of scope URLs

    Example:
        >>> get_service_scopes("drive", readonly=True)
        ['https://www.googleapis.com/auth/drive.readonly']
    """
    scope_map = {
        "drive": [ServiceScopes.DRIVE_READONLY] if readonly else [ServiceScopes.DRIVE],
        "gmail": [ServiceScopes.GMAIL_READONLY] if readonly else [ServiceScopes.GMAIL],
        "sheets": [ServiceScopes.SHEETS_READONLY] if readonly else [ServiceScopes.SHEETS],
        "calendar": [ServiceScopes.CALENDAR_READONLY] if readonly else [ServiceScopes.CALENDAR],
        "docs": [ServiceScopes.DOCS_READONLY] if readonly else [ServiceScopes.DOCS],
        # User-consentable Chat scopes (chat.bot is app-only, not user OAuth).
        # Readonly: list/resolve spaces only. Full: also send messages.
        "chat": (
            [ServiceScopes.CHAT_SPACES_READONLY]
            if readonly
            else [ServiceScopes.CHAT_MESSAGES, ServiceScopes.CHAT_SPACES_READONLY]
        ),
        "script": [
            ServiceScopes.SCRIPT_PROJECTS,
            ServiceScopes.SCRIPT_DEPLOYMENTS,
        ],
        "tasks": [ServiceScopes.TASKS_READONLY] if readonly else [ServiceScopes.TASKS],
        "slides": [ServiceScopes.SLIDES_READONLY] if readonly else [ServiceScopes.SLIDES],
        # Forms: body covers create/read; responses need their own readonly scope.
        "forms": (
            [ServiceScopes.FORMS_RESPONSES_READONLY]
            if readonly
            else [ServiceScopes.FORMS_BODY, ServiceScopes.FORMS_RESPONSES_READONLY]
        ),
        "people": (
            [ServiceScopes.CONTACTS_READONLY] if readonly else [ServiceScopes.CONTACTS]
        ),
        # Meet: created = manage spaces the user creates; readonly for lookups.
        "meet": (
            [ServiceScopes.MEET_READONLY]
            if readonly
            else [ServiceScopes.MEET_CREATED, ServiceScopes.MEET_READONLY]
        ),
        "classroom": [
            ServiceScopes.CLASSROOM_COURSES,
            ServiceScopes.CLASSROOM_ROSTERS,
        ],
        "keep": [ServiceScopes.KEEP_READONLY] if readonly else [ServiceScopes.KEEP],
    }

    scopes = scope_map.get(service.lower())
    if not scopes:
        raise ValueError(f"Unknown service: {service}")

    return [s.value for s in scopes]


def get_all_scopes(readonly: bool = False) -> List[str]:
    """
    Get all scopes for all services.

    Args:
        readonly: If True, only include readonly scopes

    Returns:
        List of all scope URLs
    """
    # Login requests only the core services in active use. The extra services
    # (tasks/slides/forms/people/meet/classroom/keep) are still reachable via
    # their `api` passthrough groups, but their scopes are intentionally left
    # out of the default login until they're actually needed.
    services = ["drive", "gmail", "sheets", "calendar", "docs", "chat", "script"]
    scopes = []
    for service in services:
        try:
            scopes.extend(get_service_scopes(service, readonly=readonly))
        except ValueError:
            continue
    return list(set(scopes))  # Remove duplicates
