"""OAuth2 credentials management for Google Workspace APIs."""

import os
from pathlib import Path
from typing import List, Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

from .token_store import LocalPickleStore, TokenStore


class CredentialsManager:
    """
    Manages OAuth2 credentials for Google Workspace APIs.

    Handles token storage, automatic refresh, and the local browser OAuth flow
    (``InstalledAppFlow``) for the CLI. Tokens are persisted to a local pickle
    file via ``LocalPickleStore``.
    """

    def __init__(
        self,
        credentials_path: Optional[str] = None,
        token_path: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ):
        """
        Initialize credentials manager.

        Args:
            credentials_path: Path to credentials.json (OAuth2 client config)
            token_path: Path to token.pickle (user auth tokens)
            scopes: List of OAuth scopes to request

        If paths are not provided, defaults to:
        - credentials: ~/.google-cli/credentials.json or ./credentials.json
        - token: ~/.google-cli/token.pickle or ./token.pickle
        """
        self.credentials_path = self._resolve_credentials_path(credentials_path)
        self.token_path = self._resolve_token_path(token_path)
        self.scopes = scopes or []
        self.token_store: TokenStore = LocalPickleStore(self.token_path)
        self.creds: Optional[Credentials] = None

    @staticmethod
    def _resolve_credentials_path(path: Optional[str]) -> Path:
        """Resolve credentials.json path with fallback logic."""
        if path:
            return Path(path).expanduser().resolve()

        # Try user config directory first
        config_dir = Path.home() / ".google-cli"
        config_path = config_dir / "credentials.json"
        if config_path.exists():
            return config_path

        # Fall back to current directory
        local_path = Path("credentials.json")
        if local_path.exists():
            return local_path

        # Check environment variable
        env_path = os.getenv("GOOGLE_CREDENTIALS")
        if env_path:
            return Path(env_path).expanduser().resolve()

        # Default to config directory (will be created if needed)
        return config_path

    @staticmethod
    def _resolve_token_path(path: Optional[str]) -> Path:
        """Resolve token.pickle path."""
        if path:
            return Path(path).expanduser().resolve()

        # Try user config directory first
        config_dir = Path.home() / ".google-cli"
        config_path = config_dir / "token.pickle"
        if config_path.exists():
            return config_path

        # Fall back to current directory
        local_path = Path("token.pickle")
        if local_path.exists():
            return local_path

        # Check environment variable
        env_path = os.getenv("GOOGLE_TOKEN_PATH")
        if env_path:
            return Path(env_path).expanduser().resolve()

        # Default to config directory
        return config_path

    def authenticate(self, force_reauth: bool = False) -> Credentials:
        """
        Authenticate and return valid credentials.

        Args:
            force_reauth: If True, force re-authentication even if token exists

        Returns:
            Valid Google OAuth2 Credentials

        Raises:
            FileNotFoundError: If credentials.json is missing
            ValueError: If authentication fails
        """
        if not self.credentials_path.exists():
            raise FileNotFoundError(
                f"Credentials file not found: {self.credentials_path}\n"
                f"Please download credentials.json from Google Cloud Console and place at:\n"
                f"  {self.credentials_path}\n"
                f"Or set GOOGLE_CREDENTIALS environment variable."
            )

        # Load existing token if available
        if not force_reauth:
            try:
                self.creds = self.token_store.load()
            except Exception as e:
                print(f"Warning: Failed to load token: {e}")
                self.creds = None

        # Refresh or authenticate
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                # Refresh expired token
                try:
                    print("Refreshing access token...")
                    self.creds.refresh(Request())
                except Exception as e:
                    print(f"Token refresh failed: {e}")
                    print("Re-authenticating...")
                    self.creds = self._run_oauth_flow()
            else:
                # Run OAuth flow for new token
                self.creds = self._run_oauth_flow()

            # Save token for future use
            self._save_token()

        return self.creds

    def _run_oauth_flow(self) -> Credentials:
        """Run OAuth2 authorization flow."""
        print(f"Starting OAuth2 flow with scopes: {self.scopes}")
        print(f"Using credentials from: {self.credentials_path}")

        try:
            flow = InstalledAppFlow.from_client_secrets_file(
                str(self.credentials_path), self.scopes
            )
            creds = flow.run_local_server(port=0)
            print("✓ Authentication successful!")
            return creds
        except Exception as e:
            raise ValueError(f"OAuth flow failed: {e}")

    def _save_token(self) -> None:
        """Persist credentials through the configured token store."""
        if not self.creds:
            return
        self.token_store.save(self.creds)

    def get_credentials(self) -> Credentials:
        """Get current credentials, authenticating if needed."""
        if not self.creds or not self.creds.valid:
            return self.authenticate()
        return self.creds

    def revoke(self) -> None:
        """Revoke current credentials and delete token."""
        if self.creds:
            try:
                self.creds.revoke(Request())
                print("✓ Credentials revoked")
            except Exception as e:
                print(f"Warning: Failed to revoke credentials: {e}")

        if self.token_store.delete():
            print("✓ Token deleted")

        self.creds = None

    def get_token_info(self) -> dict:
        """
        Get information about current token.

        Returns:
            Dictionary with token status, expiry, scopes, etc.
        """
        if not self.creds:
            return {"status": "no_credentials"}

        info = {
            "valid": self.creds.valid,
            "expired": self.creds.expired if hasattr(self.creds, "expired") else None,
            "scopes": self.creds.scopes if hasattr(self.creds, "scopes") else None,
            "token_path": str(self.token_path),
            "credentials_path": str(self.credentials_path),
        }

        if hasattr(self.creds, "expiry") and self.creds.expiry:
            info["expiry"] = self.creds.expiry.isoformat()

        if hasattr(self.creds, "refresh_token"):
            info["has_refresh_token"] = bool(self.creds.refresh_token)

        return info
