"""CLI interface for Google Workspace."""
