"""Main CLI entry point for Google Workspace CLI."""

import sys
from typing import Optional

import click

from ..core.errors import GoogleAPIError
from ..core.output import OutputFormat, output_error, output_json, output_table, output_text
from ..services.drive import DriveService


@click.group()
@click.version_option(package_name="google-workspace-cli")
def cli() -> None:
    """Google Workspace CLI - Unified interface for Google Workspace APIs."""
    pass


# ---------------------------------------------------------------------------
# Generic API passthrough command
#
# Curated commands (read/write/send/...) cover everyday use. The `api`
# subcommand exposes the *entire* official Google API surface for a service by
# dispatching through the discovery document — no per-method wrapper needed.
# ---------------------------------------------------------------------------
def _coerce_param(value: str):
    """Best-effort cast of a -p KEY=VALUE string into a typed scalar."""
    import json as _json

    low = value.lower()
    if low in ("true", "false"):
        return low == "true"
    if low in ("null", "none"):
        return None
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    if value and value[0] in "[{\"":
        try:
            return _json.loads(value)
        except ValueError:
            pass
    return value


# Workspace services exposed purely via the generic `api` passthrough (no
# curated commands). Each entry: service -> (discovery name, version, scopes).
# These mirror the official CLI's service coverage so skills/recipes that use
# Tasks, Slides, Forms, People, Meet, Classroom and Keep work here too.
from ..auth.scopes import get_service_scopes as _get_service_scopes

_GENERIC_API_SERVICES = {
    "tasks": ("tasks", "v1", _get_service_scopes("tasks")),
    "slides": ("slides", "v1", _get_service_scopes("slides")),
    "forms": ("forms", "v1", _get_service_scopes("forms")),
    "people": ("people", "v1", _get_service_scopes("people")),
    "meet": ("meet", "v2", _get_service_scopes("meet")),
    "classroom": ("classroom", "v1", _get_service_scopes("classroom")),
    "keep": ("keep", "v1", _get_service_scopes("keep")),
}


def _make_api_command(service_name: str):
    """Build a generic `api` Click command bound to one service."""
    import importlib

    _SERVICE_CLASSES = {
        "drive": ("..services.drive", "DriveService"),
        "gmail": ("..services.gmail", "GmailService"),
        "sheets": ("..services.sheets", "SheetsService"),
        "calendar": ("..services.calendar_service", "CalendarService"),
        "docs": ("..services.docs", "DocsService"),
        "chat": ("..services.chat", "ChatService"),
        "script": ("..services.script", "ScriptService"),
    }

    def _build_service(credentials):
        # Services with a dedicated class (curated commands + api).
        if service_name in _SERVICE_CLASSES:
            module_path, cls_name = _SERVICE_CLASSES[service_name]
            module = importlib.import_module(module_path, package="google_cli.cli")
            return getattr(module, cls_name)(credentials_path=credentials)
        # Generic services exposed purely through the api passthrough: build a
        # bare BaseClient from the discovery name/version/scopes table.
        from ..core.client import BaseClient

        disc, version, scopes = _GENERIC_API_SERVICES[service_name]
        return BaseClient(
            service_name=disc,
            version=version,
            credentials_path=credentials,
            scopes=scopes,
        )

    @click.command("api")
    @click.argument("method_path", required=False)
    @click.option("--params", "-P", "params_json", help="All keyword args as a JSON object")
    @click.option("--body", "-b", "body_json", help="Request body as JSON (shortcut for params.body)")
    @click.option("--param", "-p", "param_pairs", multiple=True, help="Scalar param KEY=VALUE (repeatable)")
    @click.option("--list", "list_methods", is_flag=True, help="List all available API method paths")
    @click.option("--describe", "describe", is_flag=True, help="Show schema (params/request/response) for METHOD_PATH")
    @click.option("--format", "-f", type=click.Choice(["json", "yaml"]), default="json")
    @click.option("--credentials", "-c", help="Path to credentials.json")
    def api(method_path, params_json, body_json, param_pairs, list_methods, describe, format, credentials):
        """Call ANY method of this service's official Google API.

        \b
        Examples:
          api --list                                  # list every method path
          api spreadsheets.batchUpdate --describe     # inspect params/body schema
          api spreadsheets.values.get -p spreadsheetId=ID -p range=A1:B2
          api spreadsheets.batchUpdate -p spreadsheetId=ID --body '{"requests":[...]}'
        """
        import json

        def _emit(data):
            if format == "yaml":
                from ..core.output import output_yaml
                output_yaml(data)
            else:
                output_json(data)

        try:
            service = _build_service(credentials)

            if list_methods:
                _emit(service.discover_methods())
                return

            if not method_path:
                raise click.UsageError("METHOD_PATH is required (or pass --list).")

            if describe:
                _emit(service.describe_method(method_path))
                return

            params = {}
            if params_json:
                params.update(json.loads(params_json))
            if body_json:
                params["body"] = json.loads(body_json)
            for pair in param_pairs:
                key, sep, val = pair.partition("=")
                if not sep:
                    raise click.UsageError(f"--param must be KEY=VALUE, got '{pair}'")
                params[key.strip()] = _coerce_param(val)

            result = service.call_api(method_path, **params)
            _emit(result)

        except GoogleAPIError as e:
            output_error(e, code=e.code, details=e.details)
            sys.exit(1)
        except click.UsageError:
            raise
        except json.JSONDecodeError as e:
            output_error(Exception(f"Invalid JSON: {e}"))
            sys.exit(1)
        except Exception as e:
            output_error(e)
            sys.exit(1)

    return api


@cli.command()
@click.option("--force", is_flag=True, help="Force re-login even if already logged in")
@click.option("--credentials", "-c", help="Path to credentials.json")
def login(force: bool, credentials: Optional[str]) -> None:
    """Login and authenticate with Google.

    A single browser flow always requests **all** supported service scopes
    (Drive, Gmail, Sheets, Calendar, Docs, Chat, Apps Script) so every
    google-cli command works after one login. Note: a service's commands only
    succeed if its API is enabled in Google Cloud Console.
    """
    from ..auth.logout import get_token_info
    from ..auth.credentials import CredentialsManager
    from ..auth.scopes import get_all_scopes

    click.echo("\n🔐 Google Workspace Login\n")

    # Always request the full set of service scopes.
    requested = set(get_all_scopes())

    token_info = get_token_info()
    existing = set(token_info.get("scopes") or [])

    # Already have everything? Nothing to do unless --force.
    if not force and token_info.get("token_exists") and token_info.get("valid") \
            and requested.issubset(existing):
        click.echo("✅ Already logged in — all service scopes already granted.")
        click.echo(f"Token: {token_info.get('token_path')}")
        click.echo(f"Scopes ({len(existing)}): "
                   f"{', '.join(sorted(s.split('/')[-1] for s in existing))}")
        click.echo("\nUse --force to re-run the consent flow.")
        return

    # Union with existing scopes so we never drop previously granted access.
    final_scopes = sorted(requested | existing)

    if force:
        from ..auth.logout import logout as do_logout
        click.echo("🔄 Forcing re-login...\n")
        do_logout()
        final_scopes = sorted(requested)  # clean slate on --force

    click.echo("🌐 Initiating login for: all services")
    click.echo(f"   Requesting {len(final_scopes)} scope(s). Browser will open...\n")

    try:
        manager = CredentialsManager(credentials_path=credentials, scopes=final_scopes)
        manager.authenticate(force_reauth=True)

        click.echo("\n✅ Login successful!")

        info = get_token_info()
        if info.get("token_exists"):
            click.echo(f"\nToken saved to: {info.get('token_path')}")
            granted = info.get("scopes") or final_scopes
            click.echo(f"Scopes ({len(granted)}):")
            for s in sorted(granted):
                click.echo(f"  • {s.split('/')[-1]}")
            if info.get("expiry"):
                click.echo(f"\nValid until: {info.get('expiry')}")

        click.echo("\n🚀 You can now use all google-cli commands!")

    except Exception as e:
        click.echo(f"\n❌ Login failed: {str(e)}")
        click.echo("\nTroubleshooting:")
        click.echo("  1. Check that credentials.json exists")
        click.echo("  2. Ensure the API is enabled in Google Cloud Console")
        click.echo("  3. Complete the browser authentication")
        sys.exit(1)

    click.echo()


@cli.command()
@click.option("--revoke", is_flag=True, help="Revoke credentials with Google (requires internet)")
@click.option("--delete-credentials", is_flag=True, help="Also delete credentials.json")
@click.option("--token-path", help="Custom token path")
@click.option("--credentials-path", help="Custom credentials path")
def logout(revoke: bool, delete_credentials: bool, token_path: Optional[str], credentials_path: Optional[str]) -> None:
    """Logout and delete authentication tokens."""
    from ..auth.logout import logout as do_logout, revoke_credentials

    click.echo("\n🔓 Logging out...")

    # Revoke credentials with Google if requested
    if revoke:
        click.echo("\n📡 Revoking credentials with Google...")
        if revoke_credentials(credentials_path):
            click.echo("✅ Credentials revoked successfully")
        else:
            click.echo("⚠️  Failed to revoke credentials (may already be invalid)")

    # Delete local files
    result = do_logout(
        delete_credentials=delete_credentials,
        token_path=token_path,
        credentials_path=credentials_path
    )

    # Show results
    if result["deleted"]:
        click.echo("\n✅ Deleted files:")
        for file in result["deleted"]:
            click.echo(f"   • {file}")

    if result["not_found"]:
        click.echo("\n⚠️  Files not found:")
        for file in result["not_found"]:
            click.echo(f"   • {file}")

    if result["errors"]:
        click.echo("\n❌ Errors:")
        for error in result["errors"]:
            click.echo(f"   • {error}")

    if not result["deleted"] and not result["errors"]:
        click.echo("\n✅ Already logged out (no tokens found)")
    else:
        click.echo("\n✅ Logout complete! Re-run any command to login again.")

    click.echo()


@cli.command()
@click.option("--token-path", help="Custom token path")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
def token_info(token_path: Optional[str], format: str) -> None:
    """Show current authentication token information."""
    from ..auth.logout import get_token_info

    info = get_token_info(token_path)

    if format == "json":
        output_json(info)
    else:
        click.echo("\n🔑 Token Information")
        click.echo("=" * 60)

        if "error" in info:
            click.echo(f"\n❌ Error: {info['error']}")
        elif not info.get("token_exists"):
            click.echo("\n⚠️  No authentication token found")
            click.echo(f"Token path: {info.get('token_path', 'N/A')}")
            click.echo("\nRun any command to login.")
        else:
            click.echo(f"\n✅ Token exists: {info['token_path']}")
            click.echo(f"Credentials: {info['credentials_path']}")
            click.echo(f"Valid: {info.get('valid', 'Unknown')}")

            if info.get('expired') is not None:
                status = "Expired" if info['expired'] else "Active"
                click.echo(f"Status: {status}")

            if info.get('expiry'):
                click.echo(f"Expiry: {info['expiry']}")

            if info.get('scopes'):
                click.echo(f"\nScopes ({len(info['scopes'])}):")
                for scope in info['scopes']:
                    # Extract readable name from scope URL
                    scope_name = scope.split('/')[-1]
                    click.echo(f"  • {scope_name}")

        click.echo()


@cli.group()
def drive() -> None:
    """Google Drive operations."""
    pass


@drive.command()
@click.option("--query", "-q", help="Search query (e.g., \"name contains 'report'\")")
@click.option("--limit", "-l", default=100, help="Maximum number of results")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def list(query: Optional[str], limit: int, format: str, credentials: Optional[str]) -> None:
    """List Drive files."""
    try:
        service = DriveService(credentials_path=credentials)
        result = service.list_files(query=query, max_results=limit)
        files = result["files"]

        if format == "json":
            output_json(files)
        elif format == "table":
            if files:
                output_table(
                    files,
                    columns=["name", "id", "mimeType", "size_formatted", "modifiedTime"],
                    title="Drive Files",
                )
            else:
                click.echo("No files found")
        else:  # text
            if files:
                click.echo(f"Found {len(files)} files:")
                for file in files:
                    click.echo(f"\n  {file['name']}")
                    click.echo(f"    ID: {file['id']}")
                    click.echo(f"    Type: {file.get('mimeType', 'N/A')}")
                    if "size_formatted" in file:
                        click.echo(f"    Size: {file['size_formatted']}")
            else:
                click.echo("No files found")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("file_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def get(file_id: str, format: str, credentials: Optional[str]) -> None:
    """Get file metadata by ID."""
    try:
        service = DriveService(credentials_path=credentials)
        file = service.get_file(file_id)

        if format == "json":
            output_json(file)
        else:  # text
            output_text(
                f"File: {file['name']}",
                data={
                    "id": file["id"],
                    "type": file.get("mimeType", "N/A"),
                    "size": file.get("size_formatted", "N/A"),
                    "created": file.get("createdTime", "N/A"),
                    "modified": file.get("modifiedTime", "N/A"),
                    "url": file.get("webViewLink", "N/A"),
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("keyword")
@click.option("--type", "-t", "mime_type", help="MIME type filter (e.g., 'application/pdf')")
@click.option("--limit", "-l", default=100, help="Maximum results")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def search(
    keyword: str, mime_type: Optional[str], limit: int, format: str, credentials: Optional[str]
) -> None:
    """Search for files by keyword."""
    try:
        service = DriveService(credentials_path=credentials)
        files = service.search_files(keyword, mime_type=mime_type, max_results=limit)

        if format == "json":
            output_json(files)
        elif format == "table":
            if files:
                output_table(
                    files,
                    columns=["name", "id", "mimeType", "size_formatted"],
                    title=f"Search Results: '{keyword}'",
                )
            else:
                click.echo("No files found")
        else:  # text
            if files:
                click.echo(f"Found {len(files)} files matching '{keyword}':")
                for file in files:
                    click.echo(f"  - {file['name']} ({file['id']})")
            else:
                click.echo("No files found")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--name", "-n", help="Name for file in Drive")
@click.option("--parent", "-p", help="Parent folder ID")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def upload(
    file_path: str, name: Optional[str], parent: Optional[str], format: str, credentials: Optional[str]
) -> None:
    """Upload a file to Drive."""
    try:
        service = DriveService(credentials_path=credentials)
        file = service.upload_file(file_path, name=name, parent_folder_id=parent)

        if format == "json":
            output_json(file)
        else:  # text
            output_text(
                "File uploaded successfully",
                data={
                    "id": file["id"],
                    "name": file["name"],
                    "size": file.get("size_formatted", "N/A"),
                    "url": file.get("webViewLink", "N/A"),
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("file_id")
@click.option("--output", "-o", help="Output file path")
@click.option("--dir", "-d", default="downloads", help="Output directory")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def download(
    file_id: str, output: Optional[str], dir: str, format: str, credentials: Optional[str]
) -> None:
    """Download a file from Drive."""
    try:
        service = DriveService(credentials_path=credentials)
        output_path = service.download_file(file_id, output_path=output, output_dir=dir)

        if format == "json":
            output_json({"file_path": output_path})
        else:  # text
            output_text("File downloaded successfully", data={"path": output_path})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("name")
@click.option("--parent", "-p", help="Parent folder ID")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def mkdir(name: str, parent: Optional[str], format: str, credentials: Optional[str]) -> None:
    """Create a folder."""
    try:
        service = DriveService(credentials_path=credentials)
        folder = service.create_folder(name, parent_folder_id=parent)

        if format == "json":
            output_json(folder)
        else:  # text
            output_text(
                "Folder created successfully",
                data={
                    "id": folder["id"],
                    "name": folder["name"],
                    "url": folder.get("webViewLink", "N/A"),
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("file_id")
@click.confirmation_option(prompt="Are you sure you want to delete this file?")
@click.option("--credentials", "-c", help="Path to credentials.json")
def delete(file_id: str, credentials: Optional[str]) -> None:
    """Delete a file."""
    try:
        service = DriveService(credentials_path=credentials)
        service.delete_file(file_id)
        output_text("File deleted successfully", data={"id": file_id})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@drive.command()
@click.argument("file_id")
@click.option("--email", "-e", required=True, help="Email address to share with")
@click.option(
    "--role",
    "-r",
    type=click.Choice(["reader", "writer", "owner"]),
    default="reader",
    help="Permission role",
)
@click.option("--no-notify", is_flag=True, help="Don't send notification email")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def share(
    file_id: str,
    email: str,
    role: str,
    no_notify: bool,
    format: str,
    credentials: Optional[str],
) -> None:
    """Share a file with a user."""
    try:
        service = DriveService(credentials_path=credentials)
        permission = service.share_file(file_id, email, role=role, notify=not no_notify)

        if format == "json":
            output_json(permission)
        else:  # text
            output_text(
                "File shared successfully",
                data={
                    "email": permission.get("emailAddress", email),
                    "role": permission.get("role", role),
                    "permission_id": permission["id"],
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def gmail() -> None:
    """Google Gmail operations."""
    pass


@gmail.command()
@click.option("--query", "-q", help="Gmail search query (e.g., 'is:unread')")
@click.option("--limit", "-l", default=10, help="Maximum number of results")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def list(query: Optional[str], limit: int, format: str, credentials: Optional[str]) -> None:
    """List Gmail messages."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        result = service.list_messages(query=query, max_results=limit)
        messages = result["messages"]

        if not messages:
            click.echo("No messages found")
            return

        # Get full message details
        detailed_messages = []
        for msg in messages:
            try:
                full_msg = service.get_message(msg["id"], format="metadata",
                                               metadata_headers=["From", "Subject", "Date"])
                headers = {h["name"]: h["value"] for h in full_msg.get("payload", {}).get("headers", [])}
                detailed_messages.append({
                    "id": full_msg["id"],
                    "from": headers.get("From", "N/A"),
                    "subject": headers.get("Subject", "N/A"),
                    "date": headers.get("Date", "N/A"),
                    "snippet": full_msg.get("snippet", "")
                })
            except Exception:
                pass

        if format == "json":
            output_json(detailed_messages)
        elif format == "table":
            output_table(
                detailed_messages,
                columns=["from", "subject", "date"],
                title="Gmail Messages",
            )
        else:  # text
            for msg in detailed_messages:
                click.echo(f"\nFrom: {msg['from']}")
                click.echo(f"Subject: {msg['subject']}")
                click.echo(f"Date: {msg['date']}")
                click.echo(f"Snippet: {msg['snippet'][:100]}...")
                click.echo(f"ID: {msg['id']}")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def get(message_id: str, format: str, credentials: Optional[str]) -> None:
    """Get a specific Gmail message by ID."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        message = service.get_message(message_id)

        if format == "json":
            output_json(message)
        else:  # text
            headers = {h["name"]: h["value"] for h in message.get("payload", {}).get("headers", [])}
            click.echo(f"\nMessage ID: {message['id']}")
            click.echo(f"From: {headers.get('From', 'N/A')}")
            click.echo(f"To: {headers.get('To', 'N/A')}")
            click.echo(f"Subject: {headers.get('Subject', 'N/A')}")
            click.echo(f"Date: {headers.get('Date', 'N/A')}")
            click.echo(f"\n{message.get('snippet', '')}")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.option("--to", "-t", required=True, help="Recipient email address")
@click.option("--subject", "-s", required=True, help="Email subject")
@click.option("--body", "-b", required=True, help="Email body")
@click.option("--cc", help="CC recipients (comma-separated)")
@click.option("--bcc", help="BCC recipients (comma-separated)")
@click.option("--html", is_flag=True, help="Send as HTML email")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def send(
    to: str,
    subject: str,
    body: str,
    cc: Optional[str],
    bcc: Optional[str],
    html: bool,
    format: str,
    credentials: Optional[str]
) -> None:
    """Send a Gmail message."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials)
        result = service.send_message(to=to, subject=subject, body=body, cc=cc, bcc=bcc, html=html)

        if format == "json":
            output_json(result)
        else:  # text
            output_text(
                "Message sent successfully",
                data={
                    "id": result["id"],
                    "to": to,
                    "subject": subject,
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("query")
@click.option("--limit", "-l", default=10, help="Maximum number of results")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def search(query: str, limit: int, format: str, credentials: Optional[str]) -> None:
    """Search Gmail messages."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        messages = service.search_messages(query=query, max_results=limit)

        if not messages:
            click.echo("No messages found")
            return

        # Get full message details
        detailed_messages = []
        for msg in messages:
            try:
                full_msg = service.get_message(msg["id"], format="metadata",
                                               metadata_headers=["From", "Subject", "Date"])
                headers = {h["name"]: h["value"] for h in full_msg.get("payload", {}).get("headers", [])}
                detailed_messages.append({
                    "id": full_msg["id"],
                    "from": headers.get("From", "N/A"),
                    "subject": headers.get("Subject", "N/A"),
                    "date": headers.get("Date", "N/A"),
                })
            except Exception:
                pass

        if format == "json":
            output_json(detailed_messages)
        elif format == "table":
            output_table(
                detailed_messages,
                columns=["from", "subject", "date"],
                title=f"Search Results: '{query}'",
            )
        else:  # text
            click.echo(f"Found {len(detailed_messages)} messages matching '{query}':")
            for msg in detailed_messages:
                click.echo(f"  - {msg['subject']} (from {msg['from']})")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def labels(format: str, credentials: Optional[str]) -> None:
    """List Gmail labels."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        labels_list = service.list_labels()

        if format == "json":
            output_json(labels_list)
        elif format == "table":
            output_table(
                labels_list,
                columns=["name", "id", "type"],
                title="Gmail Labels",
            )
        else:  # text
            click.echo(f"Found {len(labels_list)} labels:")
            for label in labels_list:
                click.echo(f"  - {label['name']} ({label['id']})")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--add", "-a", multiple=True, help="Label to add (ID or name). Repeatable.")
@click.option("--remove", "-r", multiple=True, help="Label to remove (ID or name). Repeatable.")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def label(
    message_id: str,
    add: tuple,
    remove: tuple,
    format: str,
    credentials: Optional[str],
) -> None:
    """Add/remove labels on a message (labels given by ID or name)."""
    from ..services.gmail import GmailService

    if not add and not remove:
        output_error(ValueError("Specify at least one --add or --remove label"))
        sys.exit(1)

    try:
        service = GmailService(credentials_path=credentials)

        # Resolve label names → IDs (IDs are passed through unchanged).
        name_to_id = {lbl["name"]: lbl["id"] for lbl in service.list_labels()}
        valid_ids = set(name_to_id.values())

        def resolve(values: tuple) -> List[str]:
            resolved: List[str] = []
            for v in values:
                if v in valid_ids:
                    resolved.append(v)
                elif v in name_to_id:
                    resolved.append(name_to_id[v])
                else:
                    raise ValueError(f"Unknown label: {v!r}")
            return resolved

        add_ids = resolve(add)
        remove_ids = resolve(remove)

        result = service.modify_message(
            message_id,
            add_label_ids=add_ids or None,
            remove_label_ids=remove_ids or None,
        )

        if format == "json":
            output_json(result)
        else:  # text
            output_text(
                "Labels updated successfully",
                data={
                    "id": result.get("id"),
                    "added": add_ids,
                    "removed": remove_ids,
                    "labels": result.get("labelIds", []),
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.option("--max", "-m", default=20, help="Maximum number of messages")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def triage(max: int, format: str, credentials: Optional[str]) -> None:
    """Show unread inbox summary (GWS-style helper)."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        messages = service.triage_inbox(max_results=max)

        if not messages:
            click.echo("No unread messages")
            return

        if format == "json":
            output_json(messages)
        elif format == "table":
            output_table(
                messages,
                columns=["from", "subject", "date"],
                title=f"Unread Messages ({len(messages)})",
            )
        else:  # text
            click.echo(f"\n📬 {len(messages)} Unread Messages:\n")
            for msg in messages:
                click.echo(f"From: {msg['from']}")
                click.echo(f"Subject: {msg['subject']}")
                click.echo(f"Date: {msg['date']}")
                click.echo(f"Snippet: {msg['snippet'][:80]}...")
                click.echo(f"ID: {msg['id']}\n")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def read(message_id: str, format: str, credentials: Optional[str]) -> None:
    """Read a message body (GWS-style helper)."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials, readonly=True)
        message = service.read_message_body(message_id)

        if format == "json":
            output_json(message)
        else:  # text
            click.echo(f"\n{'='*80}")
            click.echo(f"From: {message['from']}")
            click.echo(f"To: {message['to']}")
            click.echo(f"Subject: {message['subject']}")
            click.echo(f"Date: {message['date']}")
            click.echo(f"{'='*80}\n")
            click.echo(message['body_text'] or message['body_html'])

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--body", "-b", required=True, help="Reply body")
@click.option("--html", is_flag=True, help="Send as HTML")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def reply(message_id: str, body: str, html: bool, format: str, credentials: Optional[str]) -> None:
    """Reply to a message (GWS-style helper)."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials)
        result = service.reply_to_message(message_id, body, html=html)

        if format == "json":
            output_json(result)
        else:  # text
            output_text("Reply sent successfully", data={"id": result["id"]})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--body", "-b", required=True, help="Reply body")
@click.option("--html", is_flag=True, help="Send as HTML")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def reply_all(message_id: str, body: str, html: bool, format: str, credentials: Optional[str]) -> None:
    """Reply-all to a message (GWS-style helper)."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials)
        result = service.reply_all_to_message(message_id, body, html=html)

        if format == "json":
            output_json(result)
        else:  # text
            output_text("Reply-all sent successfully", data={"id": result["id"]})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@gmail.command()
@click.argument("message_id")
@click.option("--to", "-t", required=True, help="Recipient email")
@click.option("--body", "-b", help="Optional message to prepend")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def forward(message_id: str, to: str, body: Optional[str], format: str, credentials: Optional[str]) -> None:
    """Forward a message (GWS-style helper)."""
    from ..services.gmail import GmailService

    try:
        service = GmailService(credentials_path=credentials)
        result = service.forward_message(message_id, to, body=body)

        if format == "json":
            output_json(result)
        else:  # text
            output_text("Message forwarded successfully", data={"id": result["id"], "to": to})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def sheets() -> None:
    """Google Sheets operations."""
    pass


@sheets.command()
@click.argument("spreadsheet_id")
@click.argument("range")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table", "csv"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def read(spreadsheet_id: str, range: str, format: str, credentials: Optional[str]) -> None:
    """Read values from a spreadsheet (GWS-style helper)."""
    from ..services.sheets import SheetsService

    try:
        service = SheetsService(credentials_path=credentials, readonly=True)
        values = service.read_range(spreadsheet_id, range)

        if not values:
            click.echo("No data found")
            return

        if format == "json":
            output_json(values)
        elif format == "csv":
            import csv
            import io
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerows(values)
            click.echo(output.getvalue())
        elif format == "table":
            # Convert to list of dicts for table output
            if values:
                headers = values[0] if len(values) > 0 else []
                data = []
                for row in values[1:]:
                    row_dict = {}
                    for i, val in enumerate(row):
                        col_name = headers[i] if i < len(headers) else f"col_{i}"
                        row_dict[col_name] = val
                    data.append(row_dict)

                if data:
                    output_table(data, columns=headers, title=f"Spreadsheet: {range}")
                else:
                    click.echo("Only headers found, no data rows")
        else:  # text
            for row in values:
                click.echo("\t".join(str(cell) for cell in row))

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@sheets.command()
@click.argument("spreadsheet_id")
@click.argument("range")
@click.option("--values", "-v", required=True, help="Row values (comma-separated)")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def append(spreadsheet_id: str, range: str, values: str, format: str, credentials: Optional[str]) -> None:
    """Append a row to a spreadsheet (GWS-style helper)."""
    from ..services.sheets import SheetsService

    try:
        service = SheetsService(credentials_path=credentials)

        # Parse comma-separated values
        row_values = [v.strip() for v in values.split(",")]

        result = service.append_row(spreadsheet_id, range, row_values)

        if format == "json":
            output_json(result)
        else:  # text
            output_text(
                "Row appended successfully",
                data={
                    "range": result.get("tableRange"),
                    "updates": result.get("updates", {}).get("updatedRows", 0)
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@sheets.command()
@click.argument("spreadsheet_id")
@click.argument("range")
@click.option("--values", "-v", required=True, help="Values as JSON array (e.g., '[[1,2,3],[4,5,6]]')")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def write(spreadsheet_id: str, range: str, values: str, format: str, credentials: Optional[str]) -> None:
    """Write values to a spreadsheet."""
    from ..services.sheets import SheetsService
    import json

    try:
        service = SheetsService(credentials_path=credentials)

        # Parse JSON array
        values_array = json.loads(values)

        result = service.write_range(spreadsheet_id, range, values_array)

        if format == "json":
            output_json(result)
        else:  # text
            output_text(
                "Values written successfully",
                data={
                    "range": result.get("updatedRange"),
                    "rows": result.get("updatedRows", 0),
                    "columns": result.get("updatedColumns", 0),
                    "cells": result.get("updatedCells", 0)
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except json.JSONDecodeError as e:
        output_error(Exception(f"Invalid JSON: {e}"))
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@sheets.command()
@click.argument("title")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def create(title: str, format: str, credentials: Optional[str]) -> None:
    """Create a new spreadsheet."""
    from ..services.sheets import SheetsService

    try:
        service = SheetsService(credentials_path=credentials)
        spreadsheet = service.create_spreadsheet(title)

        if format == "json":
            output_json(spreadsheet)
        else:  # text
            output_text(
                "Spreadsheet created successfully",
                data={
                    "id": spreadsheet["spreadsheetId"],
                    "title": spreadsheet["properties"]["title"],
                    "url": spreadsheet["spreadsheetUrl"]
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@sheets.command()
@click.argument("spreadsheet_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def info(spreadsheet_id: str, format: str, credentials: Optional[str]) -> None:
    """Get spreadsheet metadata."""
    from ..services.sheets import SheetsService

    try:
        service = SheetsService(credentials_path=credentials, readonly=True)
        spreadsheet = service.get_spreadsheet(spreadsheet_id)

        if format == "json":
            output_json(spreadsheet)
        else:  # text
            props = spreadsheet["properties"]
            sheets_list = spreadsheet.get("sheets", [])

            click.echo(f"\nSpreadsheet: {props['title']}")
            click.echo(f"ID: {spreadsheet['spreadsheetId']}")
            click.echo(f"URL: {spreadsheet['spreadsheetUrl']}")
            click.echo(f"\nSheets ({len(sheets_list)}):")
            for sheet in sheets_list:
                sheet_props = sheet["properties"]
                click.echo(f"  - {sheet_props['title']} (ID: {sheet_props['sheetId']})")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def docs() -> None:
    """Google Docs operations."""
    pass


@docs.command()
@click.argument("title")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def create(title: str, format: str, credentials: Optional[str]) -> None:
    """Create a new document."""
    from ..services.docs import DocsService

    try:
        service = DocsService(credentials_path=credentials)
        doc = service.create_document(title)

        if format == "json":
            output_json(doc)
        else:  # text
            output_text(
                "Document created successfully",
                data={
                    "id": doc["documentId"],
                    "title": doc["title"],
                    "url": f"https://docs.google.com/document/d/{doc['documentId']}/edit"
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@docs.command()
@click.argument("document_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def read(document_id: str, format: str, credentials: Optional[str]) -> None:
    """Read document content (GWS-style helper)."""
    from ..services.docs import DocsService

    try:
        service = DocsService(credentials_path=credentials, readonly=True)

        if format == "json":
            doc = service.get_document(document_id)
            output_json(doc)
        else:  # text
            text = service.get_text_content(document_id)
            click.echo(text)

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@docs.command()
@click.argument("document_id")
@click.argument("text")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def write(document_id: str, text: str, format: str, credentials: Optional[str]) -> None:
    """Append text to document (GWS-style helper)."""
    from ..services.docs import DocsService

    try:
        service = DocsService(credentials_path=credentials)
        result = service.append_text(document_id, text)

        if format == "json":
            output_json(result)
        else:  # text
            output_text("Text appended successfully", data={"document_id": document_id})

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@docs.command()
@click.argument("document_id")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def info(document_id: str, format: str, credentials: Optional[str]) -> None:
    """Get document metadata."""
    from ..services.docs import DocsService

    try:
        service = DocsService(credentials_path=credentials, readonly=True)
        doc = service.get_document(document_id)

        if format == "json":
            output_json(doc)
        else:  # text
            click.echo(f"\nDocument: {doc['title']}")
            click.echo(f"ID: {doc['documentId']}")
            click.echo(f"URL: https://docs.google.com/document/d/{doc['documentId']}/edit")
            click.echo(f"Revision ID: {doc.get('revisionId', 'N/A')}")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def calendar() -> None:
    """Google Calendar operations."""
    pass


@calendar.command()
@click.option("--days", "-d", default=7, help="Number of days to show")
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def agenda(days: int, format: str, credentials: Optional[str]) -> None:
    """Show upcoming events (GWS-style helper)."""
    from ..services.calendar_service import CalendarService
    from datetime import datetime, timedelta

    try:
        service = CalendarService(credentials_path=credentials, readonly=True)

        # Get events for next N days
        now = datetime.utcnow()
        time_min = now.isoformat() + 'Z'
        time_max = (now + timedelta(days=days)).isoformat() + 'Z'

        events = service.list_events(
            time_min=time_min,
            time_max=time_max,
            max_results=50,
            single_events=True,
            order_by='startTime'
        )

        if not events:
            click.echo("No upcoming events")
            return

        if format == "json":
            output_json(events)
        elif format == "table":
            # Format for table
            formatted_events = []
            for event in events:
                start = event.get('start', {}).get('dateTime', event.get('start', {}).get('date'))
                formatted_events.append({
                    "summary": event.get('summary', '(No title)'),
                    "start": start,
                    "status": event.get('status', 'confirmed')
                })
            output_table(formatted_events, columns=["start", "summary", "status"], title=f"Upcoming Events ({days} days)")
        else:  # text
            click.echo(f"\n📅 Upcoming Events ({days} days):\n")
            for event in events:
                start = event.get('start', {}).get('dateTime', event.get('start', {}).get('date'))
                click.echo(f"{start}: {event.get('summary', '(No title)')}")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@calendar.command()
@click.option("--summary", "-s", required=True, help="Event title")
@click.option("--start", required=True, help="Start time (ISO 8601)")
@click.option("--end", required=True, help="End time (ISO 8601)")
@click.option("--description", "-d", help="Event description")
@click.option("--location", "-l", help="Event location")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def insert(
    summary: str,
    start: str,
    end: str,
    description: Optional[str],
    location: Optional[str],
    format: str,
    credentials: Optional[str]
) -> None:
    """Create a new event (GWS-style helper)."""
    from ..services.calendar_service import CalendarService

    try:
        service = CalendarService(credentials_path=credentials)

        event_body = {
            'summary': summary,
            'start': {'dateTime': start, 'timeZone': 'UTC'},
            'end': {'dateTime': end, 'timeZone': 'UTC'},
        }

        if description:
            event_body['description'] = description
        if location:
            event_body['location'] = location

        event = service.create_event(event_body)

        if format == "json":
            output_json(event)
        else:  # text
            output_text(
                "Event created successfully",
                data={
                    "id": event["id"],
                    "summary": event.get("summary"),
                    "start": event.get("start", {}).get("dateTime"),
                    "link": event.get("htmlLink")
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@calendar.command()
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def list_calendars(format: str, credentials: Optional[str]) -> None:
    """List all calendars."""
    from ..services.calendar_service import CalendarService

    try:
        service = CalendarService(credentials_path=credentials, readonly=True)
        calendars = service.list_calendars()

        if format == "json":
            output_json(calendars)
        elif format == "table":
            output_table(calendars, columns=["summary", "id", "accessRole"], title="Calendars")
        else:  # text
            click.echo(f"Found {len(calendars)} calendars:")
            for cal in calendars:
                click.echo(f"  - {cal.get('summary')} ({cal.get('id')})")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def chat() -> None:
    """Google Chat operations."""
    pass


@chat.command()
@click.argument("space")
@click.argument("text")
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def send(space: str, text: str, format: str, credentials: Optional[str]) -> None:
    """Send a message to a space (GWS-style helper)."""
    from ..services.chat import ChatService

    try:
        service = ChatService(credentials_path=credentials)
        message = service.create_message(space_name=space, text=text)

        if format == "json":
            output_json(message)
        else:  # text
            output_text(
                "Message sent successfully",
                data={
                    "name": message.get("name"),
                    "space": space,
                    "create_time": message.get("createTime")
                }
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@chat.command()
@click.option("--format", "-f", type=click.Choice(["json", "text", "table"]), default="table")
@click.option("--credentials", "-c", help="Path to credentials.json")
def list_spaces(format: str, credentials: Optional[str]) -> None:
    """List spaces."""
    from ..services.chat import ChatService

    try:
        service = ChatService(credentials_path=credentials, readonly=True)
        result = service.list_spaces()
        spaces = result.get("spaces", [])

        if format == "json":
            output_json(result)
        elif format == "table":
            formatted = []
            for space in spaces:
                formatted.append({
                    "name": space.get("name", ""),
                    "display_name": space.get("displayName", "(No name)"),
                    "type": space.get("type", "N/A")
                })
            output_table(formatted, columns=["display_name", "name", "type"], title="Chat Spaces")
        else:  # text
            click.echo(f"Found {len(spaces)} spaces:")
            for space in spaces:
                click.echo(f"  - {space.get('displayName', '(No name)')}: {space.get('name')}")

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


@cli.group()
def script() -> None:
    """Google Apps Script operations."""
    pass


@script.command()
@click.argument("script_id")
@click.option(
    "--dir", "-d", "directory", default=".",
    help="Directory containing script files (default: current dir)",
)
@click.option("--format", "-f", type=click.Choice(["json", "text"]), default="text")
@click.option("--credentials", "-c", help="Path to credentials.json")
def push(script_id: str, directory: str, format: str, credentials: Optional[str]) -> None:
    """Upload local files to an Apps Script project (replaces ALL files).

    Supports .gs, .js, .html and appsscript.json. Hidden files and
    node_modules are skipped. Mirrors the official `script +push` helper.
    """
    import os

    from ..services.script import ScriptService

    def _collect(root: str) -> list:
        collected = []
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune hidden directories and node_modules in-place.
            dirnames[:] = [
                d for d in dirnames if not d.startswith(".") and d != "node_modules"
            ]
            for fn in filenames:
                if fn.startswith("."):
                    continue
                ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
                if ext in ("gs", "js"):
                    name, ftype = fn[: -(len(ext) + 1)], "SERVER_JS"
                elif ext == "html":
                    name, ftype = fn[:-5], "HTML"
                elif fn == "appsscript.json":
                    name, ftype = "appsscript", "JSON"
                else:
                    continue
                with open(os.path.join(dirpath, fn), "r", encoding="utf-8") as fh:
                    collected.append({"name": name, "type": ftype, "source": fh.read()})
        return collected

    try:
        files = _collect(directory)
        if not files:
            output_error(
                ValueError(
                    f"No eligible files (.gs/.js/.html/appsscript.json) found in '{directory}'"
                )
            )
            sys.exit(1)

        service = ScriptService(credentials_path=credentials)
        result = service.update_content(script_id, files)

        if format == "json":
            output_json(result)
        else:  # text
            output_text(
                f"Pushed {len(files)} file(s) to project",
                data={
                    "scriptId": script_id,
                    "files": [f["name"] for f in files],
                },
            )

    except GoogleAPIError as e:
        output_error(e, code=e.code, details=e.details)
        sys.exit(1)
    except Exception as e:
        output_error(e)
        sys.exit(1)


# Register the generic `api` passthrough on every service group so the full
# official API surface is reachable alongside the curated commands.
for _group, _name in (
    (drive, "drive"),
    (gmail, "gmail"),
    (sheets, "sheets"),
    (calendar, "calendar"),
    (docs, "docs"),
    (chat, "chat"),
    (script, "script"),
):
    _group.add_command(_make_api_command(_name))


# Register API-passthrough-only groups for the remaining Workspace services.
# Each gets its own `<service> api ...` command (--list / --describe / call).
for _svc in _GENERIC_API_SERVICES:
    _grp = click.Group(
        name=_svc,
        help=f"Google {_svc.capitalize()} operations (API passthrough). "
        f"Use `{_svc} api --list` to see methods.",
    )
    _grp.add_command(_make_api_command(_svc))
    cli.add_command(_grp)


if __name__ == "__main__":
    cli()
