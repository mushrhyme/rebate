"""Google Docs service implementation."""

from typing import Any, Dict, List, Optional

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class DocsService(BaseClient):
    """Google Docs operations."""

    def __init__(self, credentials_path: Optional[str] = None, readonly: bool = False):
        """
        Initialize Docs service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, use readonly scope
        """
        scope = ServiceScopes.DOCS_READONLY if readonly else ServiceScopes.DOCS

        super().__init__(
            service_name="docs",
            version="v1",
            credentials_path=credentials_path,
            scopes=[scope.value],
        )

    # ============================================================================
    # DOCUMENT OPERATIONS
    # ============================================================================

    def create_document(self, title: str) -> Dict[str, Any]:
        """
        Create a blank document.

        Args:
            title: Document title

        Returns:
            Created document metadata
        """
        body = {"title": title}

        return self.execute_api_call(self.service.documents().create(body=body))

    def get_document(self, document_id: str) -> Dict[str, Any]:
        """
        Get document content.

        Args:
            document_id: Document ID

        Returns:
            Full document content
        """
        try:
            return self.execute_api_call(
                self.service.documents().get(documentId=document_id)
            )
        except Exception:
            raise GoogleNotFoundError("Document", document_id)

    def batch_update(
        self, document_id: str, requests: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply batch updates to document.

        Args:
            document_id: Document ID
            requests: List of update requests

        Returns:
            Update responses
        """
        body = {"requests": requests}

        return self.execute_api_call(
            self.service.documents().batchUpdate(documentId=document_id, body=body)
        )

    # ============================================================================
    # TEXT OPERATIONS (via batchUpdate)
    # ============================================================================

    def insert_text(
        self, document_id: str, index: int, text: str
    ) -> Dict[str, Any]:
        """
        Insert text at specific index.

        Args:
            document_id: Document ID
            index: Character index (1 = after title)
            text: Text to insert

        Returns:
            Update response
        """
        request = {"insertText": {"location": {"index": index}, "text": text}}

        return self.batch_update(document_id, [request])

    def delete_content(
        self, document_id: str, start_index: int, end_index: int
    ) -> Dict[str, Any]:
        """
        Delete content range.

        Args:
            document_id: Document ID
            start_index: Start index (inclusive)
            end_index: End index (exclusive)

        Returns:
            Update response
        """
        request = {
            "deleteContentRange": {
                "range": {"startIndex": start_index, "endIndex": end_index}
            }
        }

        return self.batch_update(document_id, [request])

    def replace_all_text(
        self, document_id: str, find_text: str, replace_text: str
    ) -> Dict[str, Any]:
        """
        Replace all occurrences of text.

        Args:
            document_id: Document ID
            find_text: Text to find
            replace_text: Replacement text

        Returns:
            Update response
        """
        request = {
            "replaceAllText": {
                "containsText": {"text": find_text, "matchCase": False},
                "replaceText": replace_text,
            }
        }

        return self.batch_update(document_id, [request])

    # ============================================================================
    # FORMATTING OPERATIONS
    # ============================================================================

    def update_text_style(
        self,
        document_id: str,
        start_index: int,
        end_index: int,
        text_style: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Update text style (font, size, color, bold, etc.).

        Args:
            document_id: Document ID
            start_index: Start index
            end_index: End index
            text_style: Text style object

        Returns:
            Update response
        """
        request = {
            "updateTextStyle": {
                "range": {"startIndex": start_index, "endIndex": end_index},
                "textStyle": text_style,
                "fields": "*",
            }
        }

        return self.batch_update(document_id, [request])

    def update_paragraph_style(
        self,
        document_id: str,
        start_index: int,
        end_index: int,
        paragraph_style: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Update paragraph style (alignment, indentation, spacing).

        Args:
            document_id: Document ID
            start_index: Start index
            end_index: End index
            paragraph_style: Paragraph style object

        Returns:
            Update response
        """
        request = {
            "updateParagraphStyle": {
                "range": {"startIndex": start_index, "endIndex": end_index},
                "paragraphStyle": paragraph_style,
                "fields": "*",
            }
        }

        return self.batch_update(document_id, [request])

    # ============================================================================
    # TABLE OPERATIONS
    # ============================================================================

    def insert_table(
        self, document_id: str, index: int, rows: int, columns: int
    ) -> Dict[str, Any]:
        """
        Insert a table.

        Args:
            document_id: Document ID
            index: Character index to insert at
            rows: Number of rows
            columns: Number of columns

        Returns:
            Update response
        """
        request = {
            "insertTable": {
                "location": {"index": index},
                "rows": rows,
                "columns": columns,
            }
        }

        return self.batch_update(document_id, [request])

    def insert_table_row(
        self,
        document_id: str,
        table_start_index: int,
        row_index: int,
        insert_below: bool = True,
    ) -> Dict[str, Any]:
        """Insert row into table."""
        request = {
            "insertTableRow": {
                "tableCellLocation": {
                    "tableStartLocation": {"index": table_start_index},
                    "rowIndex": row_index,
                    "columnIndex": 0,
                },
                "insertBelow": insert_below,
            }
        }

        return self.batch_update(document_id, [request])

    def insert_table_column(
        self,
        document_id: str,
        table_start_index: int,
        column_index: int,
        insert_right: bool = True,
    ) -> Dict[str, Any]:
        """Insert column into table."""
        request = {
            "insertTableColumn": {
                "tableCellLocation": {
                    "tableStartLocation": {"index": table_start_index},
                    "rowIndex": 0,
                    "columnIndex": column_index,
                },
                "insertRight": insert_right,
            }
        }

        return self.batch_update(document_id, [request])

    # ============================================================================
    # IMAGE OPERATIONS
    # ============================================================================

    def insert_inline_image(
        self, document_id: str, index: int, image_uri: str
    ) -> Dict[str, Any]:
        """
        Insert an image.

        Args:
            document_id: Document ID
            index: Character index
            image_uri: Image URL

        Returns:
            Update response
        """
        request = {
            "insertInlineImage": {"location": {"index": index}, "uri": image_uri}
        }

        return self.batch_update(document_id, [request])

    # ============================================================================
    # CONVENIENCE METHODS
    # ============================================================================

    def append_text(self, document_id: str, text: str) -> Dict[str, Any]:
        """
        Append text to end of document.

        Args:
            document_id: Document ID
            text: Text to append

        Returns:
            Update response
        """
        # Get document to find end index
        doc = self.get_document(document_id)
        end_index = doc["body"]["content"][-1]["endIndex"]

        # Insert before last index (document end marker)
        return self.insert_text(document_id, end_index - 1, text + "\n")

    def get_text_content(self, document_id: str) -> str:
        """
        Extract plain text from document.

        Args:
            document_id: Document ID

        Returns:
            Plain text content
        """
        doc = self.get_document(document_id)
        text_parts = []

        for element in doc.get("body", {}).get("content", []):
            if "paragraph" in element:
                for text_run in element["paragraph"].get("elements", []):
                    if "textRun" in text_run:
                        text_parts.append(text_run["textRun"]["content"])

        return "".join(text_parts)

    def create_heading(
        self, document_id: str, index: int, text: str, level: int = 1
    ) -> Dict[str, Any]:
        """
        Insert a heading.

        Args:
            document_id: Document ID
            index: Character index
            text: Heading text
            level: Heading level (1-6)

        Returns:
            Update response
        """
        # Insert text
        self.insert_text(document_id, index, text + "\n")

        # Format as heading
        heading_style = f"HEADING_{level}"
        request = {
            "updateParagraphStyle": {
                "range": {"startIndex": index, "endIndex": index + len(text) + 1},
                "paragraphStyle": {"namedStyleType": heading_style},
                "fields": "namedStyleType",
            }
        }

        return self.batch_update(document_id, [request])

    def make_bold(
        self, document_id: str, start_index: int, end_index: int
    ) -> Dict[str, Any]:
        """Make text bold."""
        return self.update_text_style(
            document_id, start_index, end_index, {"bold": True}
        )

    def make_italic(
        self, document_id: str, start_index: int, end_index: int
    ) -> Dict[str, Any]:
        """Make text italic."""
        return self.update_text_style(
            document_id, start_index, end_index, {"italic": True}
        )

    def change_font_size(
        self, document_id: str, start_index: int, end_index: int, size: int
    ) -> Dict[str, Any]:
        """Change font size."""
        return self.update_text_style(
            document_id, start_index, end_index, {"fontSize": {"magnitude": size, "unit": "PT"}}
        )
