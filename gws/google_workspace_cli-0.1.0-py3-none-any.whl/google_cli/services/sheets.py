"""Google Sheets service implementation."""

from typing import Any, Dict, List, Optional, Union

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class SheetsService(BaseClient):
    """Google Sheets operations."""

    def __init__(self, credentials_path: Optional[str] = None, readonly: bool = False):
        """
        Initialize Sheets service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, use readonly scope
        """
        scope = ServiceScopes.SHEETS_READONLY if readonly else ServiceScopes.SHEETS

        super().__init__(
            service_name="sheets",
            version="v4",
            credentials_path=credentials_path,
            scopes=[scope.value],
        )

    # ============================================================================
    # SPREADSHEET OPERATIONS
    # ============================================================================

    def create_spreadsheet(
        self, title: str, sheets: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Create a new spreadsheet.

        Args:
            title: Spreadsheet title
            sheets: List of sheet properties (optional)

        Returns:
            Created spreadsheet metadata
        """
        body: Dict[str, Any] = {"properties": {"title": title}}

        if sheets:
            body["sheets"] = sheets

        spreadsheet = self.execute_api_call(self.service.spreadsheets().create(body=body))

        return spreadsheet

    def get_spreadsheet(
        self,
        spreadsheet_id: str,
        ranges: Optional[List[str]] = None,
        include_grid_data: bool = False,
    ) -> Dict[str, Any]:
        """
        Get spreadsheet metadata and data.

        Args:
            spreadsheet_id: Spreadsheet ID
            ranges: Specific ranges to retrieve
            include_grid_data: Include cell data

        Returns:
            Spreadsheet data
        """
        params: Dict[str, Any] = {"spreadsheetId": spreadsheet_id}

        if ranges:
            params["ranges"] = ranges
        if include_grid_data:
            params["includeGridData"] = True

        try:
            spreadsheet = self.execute_api_call(self.service.spreadsheets().get(**params))
            return spreadsheet
        except Exception:
            raise GoogleNotFoundError("Spreadsheet", spreadsheet_id)

    def batch_update(
        self, spreadsheet_id: str, requests: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply batch updates to spreadsheet.

        Args:
            spreadsheet_id: Spreadsheet ID
            requests: List of update requests

        Returns:
            Update responses
        """
        body = {"requests": requests}

        return self.execute_api_call(
            self.service.spreadsheets().batchUpdate(spreadsheetId=spreadsheet_id, body=body)
        )

    # ============================================================================
    # VALUE OPERATIONS
    # ============================================================================

    def get_values(
        self,
        spreadsheet_id: str,
        range: str,
        value_render_option: str = "FORMATTED_VALUE",
        date_time_render_option: str = "SERIAL_NUMBER",
    ) -> Dict[str, Any]:
        """
        Get values from a range.

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation range (e.g., 'Sheet1!A1:B10')
            value_render_option: FORMATTED_VALUE, UNFORMATTED_VALUE, FORMULA
            date_time_render_option: SERIAL_NUMBER or FORMATTED_STRING

        Returns:
            Range values
        """
        result = self.execute_api_call(
            self.service.spreadsheets()
            .values()
            .get(
                spreadsheetId=spreadsheet_id,
                range=range,
                valueRenderOption=value_render_option,
                dateTimeRenderOption=date_time_render_option,
            )
        )

        return result

    def batch_get_values(
        self,
        spreadsheet_id: str,
        ranges: List[str],
        value_render_option: str = "FORMATTED_VALUE",
    ) -> Dict[str, Any]:
        """
        Get values from multiple ranges.

        Args:
            spreadsheet_id: Spreadsheet ID
            ranges: List of A1 notation ranges
            value_render_option: FORMATTED_VALUE, UNFORMATTED_VALUE, FORMULA

        Returns:
            Multiple range values
        """
        result = self.execute_api_call(
            self.service.spreadsheets()
            .values()
            .batchGet(
                spreadsheetId=spreadsheet_id,
                ranges=ranges,
                valueRenderOption=value_render_option,
            )
        )

        return result

    def update_values(
        self,
        spreadsheet_id: str,
        range: str,
        values: List[List[Any]],
        value_input_option: str = "USER_ENTERED",
    ) -> Dict[str, Any]:
        """
        Update values in a range.

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation range
            values: 2D array of values
            value_input_option: RAW or USER_ENTERED

        Returns:
            Update response
        """
        body = {"values": values}

        result = self.execute_api_call(
            self.service.spreadsheets()
            .values()
            .update(
                spreadsheetId=spreadsheet_id,
                range=range,
                valueInputOption=value_input_option,
                body=body,
            )
        )

        return result

    def batch_update_values(
        self,
        spreadsheet_id: str,
        data: List[Dict[str, Any]],
        value_input_option: str = "USER_ENTERED",
    ) -> Dict[str, Any]:
        """
        Update multiple ranges.

        Args:
            spreadsheet_id: Spreadsheet ID
            data: List of {range, values} objects
            value_input_option: RAW or USER_ENTERED

        Returns:
            Batch update response
        """
        body = {"valueInputOption": value_input_option, "data": data}

        result = self.execute_api_call(
            self.service.spreadsheets()
            .values()
            .batchUpdate(spreadsheetId=spreadsheet_id, body=body)
        )

        return result

    def append_values(
        self,
        spreadsheet_id: str,
        range: str,
        values: List[List[Any]],
        value_input_option: str = "USER_ENTERED",
        insert_data_option: str = "INSERT_ROWS",
    ) -> Dict[str, Any]:
        """
        Append values to a sheet.

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation range (table to append to)
            values: 2D array of values
            value_input_option: RAW or USER_ENTERED
            insert_data_option: INSERT_ROWS or OVERWRITE

        Returns:
            Append response
        """
        body = {"values": values}

        result = self.execute_api_call(
            self.service.spreadsheets()
            .values()
            .append(
                spreadsheetId=spreadsheet_id,
                range=range,
                valueInputOption=value_input_option,
                insertDataOption=insert_data_option,
                body=body,
            )
        )

        return result

    def clear_values(self, spreadsheet_id: str, range: str) -> Dict[str, Any]:
        """
        Clear values in a range.

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation range

        Returns:
            Clear response
        """
        result = self.execute_api_call(
            self.service.spreadsheets().values().clear(spreadsheetId=spreadsheet_id, range=range, body={})
        )

        return result

    def batch_clear_values(
        self, spreadsheet_id: str, ranges: List[str]
    ) -> Dict[str, Any]:
        """
        Clear multiple ranges.

        Args:
            spreadsheet_id: Spreadsheet ID
            ranges: List of A1 notation ranges

        Returns:
            Batch clear response
        """
        body = {"ranges": ranges}

        result = self.execute_api_call(
            self.service.spreadsheets().values().batchClear(spreadsheetId=spreadsheet_id, body=body)
        )

        return result

    # ============================================================================
    # SHEET OPERATIONS (via batchUpdate)
    # ============================================================================

    def add_sheet(
        self, spreadsheet_id: str, title: str, rows: int = 1000, columns: int = 26
    ) -> Dict[str, Any]:
        """
        Add a new sheet to spreadsheet.

        Args:
            spreadsheet_id: Spreadsheet ID
            title: Sheet title
            rows: Number of rows
            columns: Number of columns

        Returns:
            Update response
        """
        request = {
            "addSheet": {
                "properties": {
                    "title": title,
                    "gridProperties": {"rowCount": rows, "columnCount": columns},
                }
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    def delete_sheet(self, spreadsheet_id: str, sheet_id: int) -> Dict[str, Any]:
        """
        Delete a sheet.

        Args:
            spreadsheet_id: Spreadsheet ID
            sheet_id: Sheet ID (not title)

        Returns:
            Update response
        """
        request = {"deleteSheet": {"sheetId": sheet_id}}

        return self.batch_update(spreadsheet_id, [request])

    def rename_sheet(
        self, spreadsheet_id: str, sheet_id: int, new_title: str
    ) -> Dict[str, Any]:
        """
        Rename a sheet.

        Args:
            spreadsheet_id: Spreadsheet ID
            sheet_id: Sheet ID
            new_title: New sheet title

        Returns:
            Update response
        """
        request = {
            "updateSheetProperties": {
                "properties": {"sheetId": sheet_id, "title": new_title},
                "fields": "title",
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    # ============================================================================
    # FORMATTING OPERATIONS (via batchUpdate)
    # ============================================================================

    def format_cells(
        self,
        spreadsheet_id: str,
        sheet_id: int,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        format: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Format cells in a range.

        Args:
            spreadsheet_id: Spreadsheet ID
            sheet_id: Sheet ID
            start_row: Start row index (0-based)
            end_row: End row index (exclusive)
            start_col: Start column index (0-based)
            end_col: End column index (exclusive)
            format: Cell format object

        Returns:
            Update response
        """
        request = {
            "repeatCell": {
                "range": {
                    "sheetId": sheet_id,
                    "startRowIndex": start_row,
                    "endRowIndex": end_row,
                    "startColumnIndex": start_col,
                    "endColumnIndex": end_col,
                },
                "cell": {"userEnteredFormat": format},
                "fields": "userEnteredFormat",
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    def merge_cells(
        self,
        spreadsheet_id: str,
        sheet_id: int,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        merge_type: str = "MERGE_ALL",
    ) -> Dict[str, Any]:
        """
        Merge cells.

        Args:
            spreadsheet_id: Spreadsheet ID
            sheet_id: Sheet ID
            start_row: Start row index
            end_row: End row index
            start_col: Start column index
            end_col: End column index
            merge_type: MERGE_ALL, MERGE_COLUMNS, MERGE_ROWS

        Returns:
            Update response
        """
        request = {
            "mergeCells": {
                "range": {
                    "sheetId": sheet_id,
                    "startRowIndex": start_row,
                    "endRowIndex": end_row,
                    "startColumnIndex": start_col,
                    "endColumnIndex": end_col,
                },
                "mergeType": merge_type,
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    # ============================================================================
    # ROW/COLUMN OPERATIONS (via batchUpdate)
    # ============================================================================

    def insert_rows(
        self, spreadsheet_id: str, sheet_id: int, start_index: int, count: int = 1
    ) -> Dict[str, Any]:
        """Insert rows."""
        request = {
            "insertDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "ROWS",
                    "startIndex": start_index,
                    "endIndex": start_index + count,
                }
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    def insert_columns(
        self, spreadsheet_id: str, sheet_id: int, start_index: int, count: int = 1
    ) -> Dict[str, Any]:
        """Insert columns."""
        request = {
            "insertDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "COLUMNS",
                    "startIndex": start_index,
                    "endIndex": start_index + count,
                }
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    def delete_rows(
        self, spreadsheet_id: str, sheet_id: int, start_index: int, count: int = 1
    ) -> Dict[str, Any]:
        """Delete rows."""
        request = {
            "deleteDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "ROWS",
                    "startIndex": start_index,
                    "endIndex": start_index + count,
                }
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    def delete_columns(
        self, spreadsheet_id: str, sheet_id: int, start_index: int, count: int = 1
    ) -> Dict[str, Any]:
        """Delete columns."""
        request = {
            "deleteDimension": {
                "range": {
                    "sheetId": sheet_id,
                    "dimension": "COLUMNS",
                    "startIndex": start_index,
                    "endIndex": start_index + count,
                }
            }
        }

        return self.batch_update(spreadsheet_id, [request])

    # ============================================================================
    # CONVENIENCE METHODS
    # ============================================================================

    def read_range(self, spreadsheet_id: str, range: str) -> List[List[Any]]:
        """
        Read values from a range (convenience method).

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation

        Returns:
            2D array of values
        """
        result = self.get_values(spreadsheet_id, range)
        return result.get("values", [])

    def write_range(
        self, spreadsheet_id: str, range: str, values: List[List[Any]]
    ) -> Dict[str, Any]:
        """
        Write values to a range (convenience method).

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation
            values: 2D array of values

        Returns:
            Update response
        """
        return self.update_values(spreadsheet_id, range, values)

    def append_row(
        self, spreadsheet_id: str, range: str, values: List[Any]
    ) -> Dict[str, Any]:
        """
        Append a single row (convenience method).

        Args:
            spreadsheet_id: Spreadsheet ID
            range: A1 notation (table to append to)
            values: Row values

        Returns:
            Append response
        """
        return self.append_values(spreadsheet_id, range, [values])
