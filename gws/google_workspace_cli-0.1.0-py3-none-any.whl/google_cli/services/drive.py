"""Google Drive service implementation."""

import io
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError
from ..core.output import format_file_size


class DriveService(BaseClient):
    """Google Drive operations."""

    def __init__(self, credentials_path: Optional[str] = None, readonly: bool = False):
        """
        Initialize Drive service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, use readonly scope
        """
        scope = ServiceScopes.DRIVE_READONLY if readonly else ServiceScopes.DRIVE
        super().__init__(
            service_name="drive",
            version="v3",
            credentials_path=credentials_path,
            scopes=[scope.value],
        )

    def list_files(
        self,
        query: Optional[str] = None,
        max_results: int = 100,
        page_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List Drive files.

        Args:
            query: Search query (e.g., "name contains 'report'")
            max_results: Maximum number of results (1-1000)
            page_token: Token for pagination

        Returns:
            Dictionary with files list and next page token
        """
        params = {
            "pageSize": min(max_results, 1000),
            "fields": "nextPageToken, files(id, name, mimeType, size, createdTime, modifiedTime, webViewLink)",
        }

        if query:
            params["q"] = query

        if page_token:
            params["pageToken"] = page_token

        result = self.execute_api_call(self.service.files().list(**params))

        # Format file sizes for readability
        files = result.get("files", [])
        for file in files:
            if "size" in file:
                file["size_formatted"] = format_file_size(int(file["size"]))

        return {"files": files, "next_page_token": result.get("nextPageToken")}

    def get_file(self, file_id: str) -> Dict[str, Any]:
        """
        Get file metadata.

        Args:
            file_id: Drive file ID

        Returns:
            File metadata dictionary
        """
        try:
            file = self.execute_api_call(
                self.service.files().get(
                    fileId=file_id,
                    fields="id, name, mimeType, size, createdTime, modifiedTime, parents, webViewLink, owners",
                )
            )

            if "size" in file:
                file["size_formatted"] = format_file_size(int(file["size"]))

            return file
        except Exception:
            raise GoogleNotFoundError("File", file_id)

    def search_files(
        self, keyword: str, mime_type: Optional[str] = None, max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Search for files by keyword.

        Args:
            keyword: Search keyword
            mime_type: Optional MIME type filter
            max_results: Maximum results to return

        Returns:
            List of matching files
        """
        query = f"name contains '{keyword}'"
        if mime_type:
            query += f" and mimeType='{mime_type}'"

        result = self.list_files(query=query, max_results=max_results)
        return result["files"]

    def upload_file(
        self,
        file_path: str,
        name: Optional[str] = None,
        parent_folder_id: Optional[str] = None,
        mime_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Upload a file to Drive.

        Args:
            file_path: Path to local file
            name: Name for file in Drive (defaults to local filename)
            parent_folder_id: Parent folder ID (None for root)
            mime_type: MIME type (auto-detected if None)

        Returns:
            Uploaded file metadata
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        file_metadata: Dict[str, Any] = {"name": name or path.name}

        if parent_folder_id:
            file_metadata["parents"] = [parent_folder_id]

        media = MediaFileUpload(str(path), mimetype=mime_type, resumable=True)

        file = self.execute_api_call(
            self.service.files().create(body=file_metadata, media_body=media, fields="id, name, webViewLink, size")
        )

        if "size" in file:
            file["size_formatted"] = format_file_size(int(file["size"]))

        return file

    def download_file(
        self, file_id: str, output_path: Optional[str] = None, output_dir: str = "downloads"
    ) -> str:
        """
        Download a file from Drive.

        Args:
            file_id: Drive file ID
            output_path: Full output path (if None, uses output_dir + filename)
            output_dir: Output directory (used if output_path is None)

        Returns:
            Path to downloaded file
        """
        # Get file metadata
        file = self.get_file(file_id)
        file_name = file["name"]

        # Handle Google Workspace files (need export)
        mime_type = file.get("mimeType", "")
        if "google-apps" in mime_type:
            return self._export_google_file(file_id, file_name, mime_type, output_path, output_dir)

        # Determine output path
        if output_path is None:
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, file_name)

        # Download file
        request = self.service.files().get_media(fileId=file_id)
        fh = io.FileIO(output_path, "wb")
        downloader = MediaIoBaseDownload(fh, request)

        done = False
        while not done:
            status, done = downloader.next_chunk()

        return output_path

    def _export_google_file(
        self,
        file_id: str,
        file_name: str,
        mime_type: str,
        output_path: Optional[str],
        output_dir: str,
    ) -> str:
        """Export Google Workspace file (Docs, Sheets, Slides)."""
        # Determine export format
        export_map = {
            "application/vnd.google-apps.document": ("application/pdf", ".pdf"),
            "application/vnd.google-apps.spreadsheet": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ".xlsx",
            ),
            "application/vnd.google-apps.presentation": (
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                ".pptx",
            ),
        }

        if mime_type not in export_map:
            raise ValueError(f"Cannot export file type: {mime_type}")

        export_mime, extension = export_map[mime_type]

        # Determine output path
        if output_path is None:
            os.makedirs(output_dir, exist_ok=True)
            base_name = os.path.splitext(file_name)[0]
            output_path = os.path.join(output_dir, base_name + extension)

        # Export file
        request = self.service.files().export_media(fileId=file_id, mimeType=export_mime)
        fh = io.FileIO(output_path, "wb")
        downloader = MediaIoBaseDownload(fh, request)

        done = False
        while not done:
            status, done = downloader.next_chunk()

        return output_path

    def create_folder(self, name: str, parent_folder_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a folder.

        Args:
            name: Folder name
            parent_folder_id: Parent folder ID (None for root)

        Returns:
            Created folder metadata
        """
        file_metadata = {
            "name": name,
            "mimeType": "application/vnd.google-apps.folder",
        }

        if parent_folder_id:
            file_metadata["parents"] = [parent_folder_id]

        folder = self.execute_api_call(
            self.service.files().create(body=file_metadata, fields="id, name, webViewLink")
        )

        return folder

    def delete_file(self, file_id: str) -> None:
        """
        Delete a file.

        Args:
            file_id: Drive file ID
        """
        self.execute_api_call(self.service.files().delete(fileId=file_id))

    def share_file(
        self, file_id: str, email: str, role: str = "reader", notify: bool = True
    ) -> Dict[str, Any]:
        """
        Share a file with a user.

        Args:
            file_id: Drive file ID
            email: Email address to share with
            role: Permission role (reader, writer, owner)
            notify: Send notification email

        Returns:
            Permission metadata
        """
        permission = {
            "type": "user",
            "role": role,
            "emailAddress": email,
        }

        result = self.execute_api_call(
            self.service.permissions().create(
                fileId=file_id,
                body=permission,
                sendNotificationEmail=notify,
                fields="id, emailAddress, role",
            )
        )

        return result
