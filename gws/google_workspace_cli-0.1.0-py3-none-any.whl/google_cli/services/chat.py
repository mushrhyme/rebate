"""Google Chat service implementation."""

from typing import Any, Dict, List, Optional

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class ChatService(BaseClient):
    """Google Chat operations."""

    def __init__(
        self, credentials_path: Optional[str] = None, readonly: bool = False
    ):
        """
        Initialize Chat service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, request only the read-only spaces scope
                (sufficient for list_spaces / find_direct_message)
        """
        # chat.messages → send/read; chat.spaces.readonly → list_spaces /
        # find_direct_message. readonly callers only need the latter.
        scopes = [ServiceScopes.CHAT_SPACES_READONLY.value]
        if not readonly:
            scopes.insert(0, ServiceScopes.CHAT_MESSAGES.value)

        super().__init__(
            service_name="chat",
            version="v1",
            credentials_path=credentials_path,
            scopes=scopes,
        )

    # ============================================================================
    # SPACE OPERATIONS
    # ============================================================================

    def list_spaces(
        self, page_size: int = 100, page_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List spaces.

        Args:
            page_size: Maximum results per page
            page_token: Page token

        Returns:
            Dictionary with spaces list and next page token
        """
        params: Dict[str, Any] = {"pageSize": page_size}

        if page_token:
            params["pageToken"] = page_token

        result = self.execute_api_call(self.service.spaces().list(**params))

        return {
            "spaces": result.get("spaces", []),
            "next_page_token": result.get("nextPageToken"),
        }

    def get_space(self, space_name: str) -> Dict[str, Any]:
        """
        Get space by name.

        Args:
            space_name: Space resource name (spaces/SPACE_ID)

        Returns:
            Space details
        """
        try:
            return self.execute_api_call(self.service.spaces().get(name=space_name))
        except Exception:
            raise GoogleNotFoundError("Space", space_name)

    def create_space(
        self, display_name: str, space_type: str = "SPACE"
    ) -> Dict[str, Any]:
        """
        Create a space.

        Args:
            display_name: Space name
            space_type: SPACE or GROUP_CHAT

        Returns:
            Created space
        """
        body = {"displayName": display_name, "spaceType": space_type}

        return self.execute_api_call(self.service.spaces().create(body=body))

    def update_space(
        self, space_name: str, display_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update space properties."""
        body: Dict[str, Any] = {}
        update_mask = []

        if display_name:
            body["displayName"] = display_name
            update_mask.append("displayName")

        return self.execute_api_call(
            self.service.spaces().patch(
                name=space_name, body=body, updateMask=",".join(update_mask)
            )
        )

    def delete_space(self, space_name: str) -> None:
        """Delete a space."""
        self.execute_api_call(self.service.spaces().delete(name=space_name))

    def find_direct_message(self, user_email: str) -> Dict[str, Any]:
        """
        Find direct message space with user.

        Args:
            user_email: User email address

        Returns:
            DM space
        """
        result = self.execute_api_call(
            self.service.spaces().findDirectMessage(name=f"users/{user_email}")
        )
        return result

    # ============================================================================
    # MESSAGE OPERATIONS
    # ============================================================================

    def list_messages(
        self, space_name: str, page_size: int = 100, page_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List messages in a space.

        Args:
            space_name: Space resource name
            page_size: Maximum results
            page_token: Page token

        Returns:
            Messages and next page token
        """
        parent = space_name
        params: Dict[str, Any] = {"parent": parent, "pageSize": page_size}

        if page_token:
            params["pageToken"] = page_token

        result = self.execute_api_call(self.service.spaces().messages().list(**params))

        return {
            "messages": result.get("messages", []),
            "next_page_token": result.get("nextPageToken"),
        }

    def get_message(self, message_name: str) -> Dict[str, Any]:
        """
        Get message by name.

        Args:
            message_name: Message resource name (spaces/SPACE/messages/MESSAGE)

        Returns:
            Message details
        """
        try:
            return self.execute_api_call(
                self.service.spaces().messages().get(name=message_name)
            )
        except Exception:
            raise GoogleNotFoundError("Message", message_name)

    def create_message(
        self,
        space_name: str,
        text: Optional[str] = None,
        cards: Optional[List[Dict[str, Any]]] = None,
        thread_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Send a message to a space.

        Args:
            space_name: Space resource name
            text: Plain text message
            cards: Card messages (rich UI)
            thread_key: Thread key for threading messages

        Returns:
            Created message
        """
        parent = space_name
        body: Dict[str, Any] = {}

        if text:
            body["text"] = text
        if cards:
            body["cardsV2"] = cards

        params: Dict[str, Any] = {"parent": parent, "body": body}

        if thread_key:
            params["threadKey"] = thread_key

        return self.execute_api_call(self.service.spaces().messages().create(**params))

    def update_message(
        self, message_name: str, text: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a message.

        Args:
            message_name: Message resource name
            text: New message text

        Returns:
            Updated message
        """
        body: Dict[str, Any] = {}
        update_mask = []

        if text:
            body["text"] = text
            update_mask.append("text")

        return self.execute_api_call(
            self.service.spaces()
            .messages()
            .update(name=message_name, body=body, updateMask=",".join(update_mask))
        )

    def delete_message(self, message_name: str) -> None:
        """Delete a message."""
        self.execute_api_call(self.service.spaces().messages().delete(name=message_name))

    # ============================================================================
    # MEMBER OPERATIONS
    # ============================================================================

    def list_members(
        self, space_name: str, page_size: int = 100
    ) -> List[Dict[str, Any]]:
        """
        List space members.

        Args:
            space_name: Space resource name
            page_size: Maximum results

        Returns:
            List of members
        """
        parent = space_name
        result = self.execute_api_call(
            self.service.spaces().members().list(parent=parent, pageSize=page_size)
        )

        return result.get("memberships", [])

    def get_member(self, member_name: str) -> Dict[str, Any]:
        """Get member by name."""
        return self.execute_api_call(self.service.spaces().members().get(name=member_name))

    def create_member(
        self, space_name: str, user_email: str, role: str = "ROLE_MEMBER"
    ) -> Dict[str, Any]:
        """
        Add member to space.

        Args:
            space_name: Space resource name
            user_email: User email
            role: ROLE_MEMBER or ROLE_MANAGER

        Returns:
            Created membership
        """
        parent = space_name
        body = {
            "member": {"name": f"users/{user_email}", "type": "HUMAN"},
            "role": role,
        }

        return self.execute_api_call(
            self.service.spaces().members().create(parent=parent, body=body)
        )

    def delete_member(self, member_name: str) -> None:
        """Remove member from space."""
        self.execute_api_call(self.service.spaces().members().delete(name=member_name))

    # ============================================================================
    # CONVENIENCE METHODS
    # ============================================================================

    def send_text(self, space_name: str, text: str) -> Dict[str, Any]:
        """
        Send simple text message (convenience method).

        Args:
            space_name: Space resource name
            text: Message text

        Returns:
            Created message
        """
        return self.create_message(space_name, text=text)

    def send_dm(self, user_email: str, text: str) -> Dict[str, Any]:
        """
        Send direct message to user.

        Args:
            user_email: User email
            text: Message text

        Returns:
            Created message
        """
        # Find or create DM space
        dm_space = self.find_direct_message(user_email)
        space_name = dm_space["name"]

        return self.send_text(space_name, text)

    def send_card(self, space_name: str, card: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send card message.

        Args:
            space_name: Space resource name
            card: Card object

        Returns:
            Created message
        """
        return self.create_message(space_name, cards=[{"card": card}])
