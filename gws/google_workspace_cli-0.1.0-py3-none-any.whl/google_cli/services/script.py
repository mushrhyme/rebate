"""Google Apps Script service implementation."""

from typing import Any, Dict, List, Optional

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class ScriptService(BaseClient):
    """Google Apps Script operations."""

    def __init__(self, credentials_path: Optional[str] = None):
        """
        Initialize Script service.

        Args:
            credentials_path: Path to credentials.json
        """
        super().__init__(
            service_name="script",
            version="v1",
            credentials_path=credentials_path,
            scopes=[ServiceScopes.SCRIPT_PROJECTS.value],
        )

    # ============================================================================
    # PROJECT OPERATIONS
    # ============================================================================

    def create_project(self, title: str, parent_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new script project.

        Args:
            title: Project title
            parent_id: Optional parent container ID (Drive file ID)

        Returns:
            Created project
        """
        body: Dict[str, Any] = {"title": title}

        if parent_id:
            body["parentId"] = parent_id

        return self.execute_api_call(self.service.projects().create(body=body))

    def get_project(self, script_id: str) -> Dict[str, Any]:
        """
        Get project metadata.

        Args:
            script_id: Script project ID

        Returns:
            Project metadata
        """
        try:
            return self.execute_api_call(self.service.projects().get(scriptId=script_id))
        except Exception:
            raise GoogleNotFoundError("Script Project", script_id)

    def get_content(self, script_id: str) -> Dict[str, Any]:
        """
        Get project content (all files).

        Args:
            script_id: Script project ID

        Returns:
            Project files and manifest
        """
        return self.execute_api_call(
            self.service.projects().getContent(scriptId=script_id)
        )

    def update_content(
        self, script_id: str, files: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Update project content.

        Args:
            script_id: Script project ID
            files: List of file objects with name, type, source

        Returns:
            Updated content
        """
        body = {"files": files}

        return self.execute_api_call(
            self.service.projects().updateContent(scriptId=script_id, body=body)
        )

    # ============================================================================
    # DEPLOYMENT OPERATIONS
    # ============================================================================

    def list_deployments(self, script_id: str) -> List[Dict[str, Any]]:
        """
        List project deployments.

        Args:
            script_id: Script project ID

        Returns:
            List of deployments
        """
        result = self.execute_api_call(
            self.service.projects().deployments().list(scriptId=script_id)
        )

        return result.get("deployments", [])

    def get_deployment(self, script_id: str, deployment_id: str) -> Dict[str, Any]:
        """Get deployment by ID."""
        return self.execute_api_call(
            self.service.projects()
            .deployments()
            .get(scriptId=script_id, deploymentId=deployment_id)
        )

    def create_deployment(
        self,
        script_id: str,
        version_number: int,
        description: Optional[str] = None,
        manifest_file_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new deployment.

        Args:
            script_id: Script project ID
            version_number: Version number to deploy
            description: Deployment description
            manifest_file_name: Manifest file name (default: appsscript.json)

        Returns:
            Created deployment
        """
        body: Dict[str, Any] = {
            "versionNumber": version_number,
            "deploymentConfig": {},
        }

        if description:
            body["description"] = description
        if manifest_file_name:
            body["deploymentConfig"]["manifestFileName"] = manifest_file_name

        return self.execute_api_call(
            self.service.projects().deployments().create(scriptId=script_id, body=body)
        )

    def update_deployment(
        self, script_id: str, deployment_id: str, version_number: int
    ) -> Dict[str, Any]:
        """Update a deployment to a new version."""
        body = {"deploymentConfig": {"versionNumber": version_number}}

        return self.execute_api_call(
            self.service.projects()
            .deployments()
            .update(scriptId=script_id, deploymentId=deployment_id, body=body)
        )

    def delete_deployment(self, script_id: str, deployment_id: str) -> None:
        """Delete a deployment."""
        self.execute_api_call(
            self.service.projects()
            .deployments()
            .delete(scriptId=script_id, deploymentId=deployment_id)
        )

    # ============================================================================
    # VERSION OPERATIONS
    # ============================================================================

    def list_versions(self, script_id: str) -> List[Dict[str, Any]]:
        """List project versions."""
        result = self.execute_api_call(
            self.service.projects().versions().list(scriptId=script_id)
        )

        return result.get("versions", [])

    def get_version(self, script_id: str, version_number: int) -> Dict[str, Any]:
        """Get specific version."""
        return self.execute_api_call(
            self.service.projects()
            .versions()
            .get(scriptId=script_id, versionNumber=version_number)
        )

    def create_version(
        self, script_id: str, description: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new version.

        Args:
            script_id: Script project ID
            description: Version description

        Returns:
            Created version
        """
        body: Dict[str, Any] = {}

        if description:
            body["description"] = description

        return self.execute_api_call(
            self.service.projects().versions().create(scriptId=script_id, body=body)
        )

    # ============================================================================
    # SCRIPT EXECUTION
    # ============================================================================

    def run_function(
        self,
        script_id: str,
        function_name: str,
        parameters: Optional[List[Any]] = None,
        dev_mode: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute a script function.

        Args:
            script_id: Script project ID
            function_name: Function name to execute
            parameters: Function parameters
            dev_mode: Run in dev mode

        Returns:
            Execution result
        """
        body: Dict[str, Any] = {"function": function_name}

        if parameters:
            body["parameters"] = parameters
        if dev_mode:
            body["devMode"] = True

        return self.execute_api_call(
            self.service.scripts().run(scriptId=script_id, body=body)
        )

    # ============================================================================
    # CONVENIENCE METHODS
    # ============================================================================

    def deploy_from_local(
        self,
        script_id: str,
        local_files: Dict[str, str],
        version_description: str = "New version",
    ) -> Dict[str, Any]:
        """
        Deploy local files to script project.

        Args:
            script_id: Script project ID
            local_files: Dict of {filename: source_code}
            version_description: Version description

        Returns:
            Deployment info
        """
        # Format files for API
        files = []
        for name, source in local_files.items():
            file_type = "SERVER_JS" if name.endswith(".gs") else "JSON"
            files.append({"name": name, "type": file_type, "source": source})

        # Update content
        self.update_content(script_id, files)

        # Create version
        version = self.create_version(script_id, version_description)

        # Create deployment
        deployment = self.create_deployment(
            script_id, version["versionNumber"], version_description
        )

        return deployment

    def get_project_url(self, script_id: str) -> str:
        """Get script editor URL."""
        return f"https://script.google.com/d/{script_id}/edit"

    def get_web_app_url(self, script_id: str, deployment_id: str) -> str:
        """Get deployed web app URL."""
        return f"https://script.google.com/macros/s/{deployment_id}/exec"
