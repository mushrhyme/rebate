"""Google Gmail service implementation."""

import base64
import mimetypes
import os
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class GmailService(BaseClient):
    """Google Gmail operations."""

    def __init__(self, credentials_path: Optional[str] = None, readonly: bool = False):
        """
        Initialize Gmail service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, use readonly scope
        """
        if readonly:
            scope = ServiceScopes.GMAIL_READONLY
        else:
            scope = ServiceScopes.GMAIL

        super().__init__(
            service_name="gmail",
            version="v1",
            credentials_path=credentials_path,
            scopes=[scope.value],
        )

    # ============================================================================
    # MESSAGE OPERATIONS
    # ============================================================================

    def list_messages(
        self,
        user_id: str = "me",
        query: Optional[str] = None,
        label_ids: Optional[List[str]] = None,
        max_results: int = 100,
        page_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List messages in mailbox.

        Args:
            user_id: User's email address or 'me'
            query: Gmail search query (e.g., 'is:unread from:user@example.com')
            label_ids: Filter by label IDs
            max_results: Maximum results per page
            page_token: Page token for pagination

        Returns:
            Dictionary with messages list and next page token
        """
        params: Dict[str, Any] = {"userId": user_id, "maxResults": max_results}

        if query:
            params["q"] = query
        if label_ids:
            params["labelIds"] = label_ids
        if page_token:
            params["pageToken"] = page_token

        result = self.execute_api_call(self.service.users().messages().list(**params))

        return {
            "messages": result.get("messages", []),
            "next_page_token": result.get("nextPageToken"),
            "result_size_estimate": result.get("resultSizeEstimate", 0),
        }

    def get_message(
        self,
        message_id: str,
        user_id: str = "me",
        format: str = "full",
        metadata_headers: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Get message by ID.

        Args:
            message_id: Message ID
            user_id: User's email address or 'me'
            format: Format (minimal, full, raw, metadata)
            metadata_headers: Headers to include if format=metadata

        Returns:
            Message details
        """
        params: Dict[str, Any] = {"userId": user_id, "id": message_id, "format": format}

        if metadata_headers and format == "metadata":
            params["metadataHeaders"] = metadata_headers

        try:
            message = self.execute_api_call(self.service.users().messages().get(**params))
            return message
        except Exception:
            raise GoogleNotFoundError("Message", message_id)

    def send_message(
        self,
        to: str,
        subject: str,
        body: str,
        user_id: str = "me",
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        html: bool = False,
        in_reply_to: Optional[str] = None,
        references: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Send an email message.

        Args:
            to: Recipient email address
            subject: Email subject
            body: Email body
            user_id: Sender user ID
            cc: CC recipients (comma-separated)
            bcc: BCC recipients (comma-separated)
            attachments: List of file paths to attach
            html: If True, send as HTML email
            in_reply_to: Message-ID to reply to
            references: Reference Message-IDs

        Returns:
            Sent message metadata
        """
        message = self._create_message(
            to, subject, body, cc, bcc, attachments, html, in_reply_to, references
        )

        result = self.execute_api_call(
            self.service.users().messages().send(userId=user_id, body={"raw": message})
        )

        return result

    def modify_message(
        self,
        message_id: str,
        add_label_ids: Optional[List[str]] = None,
        remove_label_ids: Optional[List[str]] = None,
        user_id: str = "me",
    ) -> Dict[str, Any]:
        """
        Modify message labels.

        Args:
            message_id: Message ID
            add_label_ids: Label IDs to add
            remove_label_ids: Label IDs to remove
            user_id: User ID

        Returns:
            Modified message
        """
        body: Dict[str, Any] = {}
        if add_label_ids:
            body["addLabelIds"] = add_label_ids
        if remove_label_ids:
            body["removeLabelIds"] = remove_label_ids

        result = self.execute_api_call(
            self.service.users().messages().modify(userId=user_id, id=message_id, body=body)
        )

        return result

    def trash_message(self, message_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Move message to trash."""
        return self.execute_api_call(
            self.service.users().messages().trash(userId=user_id, id=message_id)
        )

    def untrash_message(self, message_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Remove message from trash."""
        return self.execute_api_call(
            self.service.users().messages().untrash(userId=user_id, id=message_id)
        )

    def delete_message(self, message_id: str, user_id: str = "me") -> None:
        """Permanently delete message."""
        self.execute_api_call(
            self.service.users().messages().delete(userId=user_id, id=message_id)
        )

    def batch_modify_messages(
        self,
        message_ids: List[str],
        add_label_ids: Optional[List[str]] = None,
        remove_label_ids: Optional[List[str]] = None,
        user_id: str = "me",
    ) -> None:
        """Batch modify message labels."""
        body: Dict[str, Any] = {"ids": message_ids}
        if add_label_ids:
            body["addLabelIds"] = add_label_ids
        if remove_label_ids:
            body["removeLabelIds"] = remove_label_ids

        self.execute_api_call(
            self.service.users().messages().batchModify(userId=user_id, body=body)
        )

    def batch_delete_messages(self, message_ids: List[str], user_id: str = "me") -> None:
        """Batch delete messages."""
        self.execute_api_call(
            self.service.users().messages().batchDelete(userId=user_id, body={"ids": message_ids})
        )

    def get_attachment(
        self, message_id: str, attachment_id: str, output_path: Optional[str] = None, user_id: str = "me"
    ) -> str:
        """
        Download message attachment.

        Args:
            message_id: Message ID
            attachment_id: Attachment ID
            output_path: Path to save attachment
            user_id: User ID

        Returns:
            Path to downloaded file or base64 data if no output_path
        """
        attachment = self.execute_api_call(
            self.service.users()
            .messages()
            .attachments()
            .get(userId=user_id, messageId=message_id, id=attachment_id)
        )

        data = attachment["data"]
        file_data = base64.urlsafe_b64decode(data)

        if output_path:
            with open(output_path, "wb") as f:
                f.write(file_data)
            return output_path
        else:
            return base64.b64encode(file_data).decode()

    # ============================================================================
    # LABEL OPERATIONS
    # ============================================================================

    def list_labels(self, user_id: str = "me") -> List[Dict[str, Any]]:
        """List all labels."""
        result = self.execute_api_call(self.service.users().labels().list(userId=user_id))
        return result.get("labels", [])

    def get_label(self, label_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Get label by ID."""
        return self.execute_api_call(
            self.service.users().labels().get(userId=user_id, id=label_id)
        )

    def create_label(
        self, name: str, label_list_visibility: str = "labelShow", message_list_visibility: str = "show", user_id: str = "me"
    ) -> Dict[str, Any]:
        """
        Create a new label.

        Args:
            name: Label name
            label_list_visibility: labelShow or labelHide
            message_list_visibility: show or hide
            user_id: User ID

        Returns:
            Created label
        """
        body = {
            "name": name,
            "labelListVisibility": label_list_visibility,
            "messageListVisibility": message_list_visibility,
        }

        return self.execute_api_call(
            self.service.users().labels().create(userId=user_id, body=body)
        )

    def update_label(
        self, label_id: str, name: Optional[str] = None, user_id: str = "me"
    ) -> Dict[str, Any]:
        """Update label."""
        body: Dict[str, Any] = {}
        if name:
            body["name"] = name

        return self.execute_api_call(
            self.service.users().labels().update(userId=user_id, id=label_id, body=body)
        )

    def delete_label(self, label_id: str, user_id: str = "me") -> None:
        """Delete label."""
        self.execute_api_call(self.service.users().labels().delete(userId=user_id, id=label_id))

    # ============================================================================
    # DRAFT OPERATIONS
    # ============================================================================

    def list_drafts(self, user_id: str = "me", max_results: int = 100) -> List[Dict[str, Any]]:
        """List drafts."""
        result = self.execute_api_call(
            self.service.users().drafts().list(userId=user_id, maxResults=max_results)
        )
        return result.get("drafts", [])

    def get_draft(self, draft_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Get draft by ID."""
        return self.execute_api_call(
            self.service.users().drafts().get(userId=user_id, id=draft_id)
        )

    def create_draft(
        self, to: str, subject: str, body: str, user_id: str = "me", html: bool = False
    ) -> Dict[str, Any]:
        """Create a draft message."""
        message = self._create_message(to, subject, body, html=html)

        draft_body = {"message": {"raw": message}}

        return self.execute_api_call(
            self.service.users().drafts().create(userId=user_id, body=draft_body)
        )

    def update_draft(
        self, draft_id: str, to: str, subject: str, body: str, user_id: str = "me", html: bool = False
    ) -> Dict[str, Any]:
        """Update a draft."""
        message = self._create_message(to, subject, body, html=html)

        draft_body = {"message": {"raw": message}}

        return self.execute_api_call(
            self.service.users().drafts().update(userId=user_id, id=draft_id, body=draft_body)
        )

    def send_draft(self, draft_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Send a draft."""
        return self.execute_api_call(
            self.service.users().drafts().send(userId=user_id, body={"id": draft_id})
        )

    def delete_draft(self, draft_id: str, user_id: str = "me") -> None:
        """Delete a draft."""
        self.execute_api_call(self.service.users().drafts().delete(userId=user_id, id=draft_id))

    # ============================================================================
    # THREAD OPERATIONS
    # ============================================================================

    def list_threads(
        self,
        user_id: str = "me",
        query: Optional[str] = None,
        label_ids: Optional[List[str]] = None,
        max_results: int = 100,
    ) -> List[Dict[str, Any]]:
        """List email threads."""
        params: Dict[str, Any] = {"userId": user_id, "maxResults": max_results}

        if query:
            params["q"] = query
        if label_ids:
            params["labelIds"] = label_ids

        result = self.execute_api_call(self.service.users().threads().list(**params))
        return result.get("threads", [])

    def get_thread(self, thread_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Get thread by ID."""
        return self.execute_api_call(
            self.service.users().threads().get(userId=user_id, id=thread_id)
        )

    def modify_thread(
        self,
        thread_id: str,
        add_label_ids: Optional[List[str]] = None,
        remove_label_ids: Optional[List[str]] = None,
        user_id: str = "me",
    ) -> Dict[str, Any]:
        """Modify thread labels."""
        body: Dict[str, Any] = {}
        if add_label_ids:
            body["addLabelIds"] = add_label_ids
        if remove_label_ids:
            body["removeLabelIds"] = remove_label_ids

        return self.execute_api_call(
            self.service.users().threads().modify(userId=user_id, id=thread_id, body=body)
        )

    def trash_thread(self, thread_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Move thread to trash."""
        return self.execute_api_call(
            self.service.users().threads().trash(userId=user_id, id=thread_id)
        )

    def untrash_thread(self, thread_id: str, user_id: str = "me") -> Dict[str, Any]:
        """Remove thread from trash."""
        return self.execute_api_call(
            self.service.users().threads().untrash(userId=user_id, id=thread_id)
        )

    def delete_thread(self, thread_id: str, user_id: str = "me") -> None:
        """Permanently delete thread."""
        self.execute_api_call(self.service.users().threads().delete(userId=user_id, id=thread_id))

    # ============================================================================
    # HELPER METHODS
    # ============================================================================

    def _create_message(
        self,
        to: str,
        subject: str,
        body: str,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        html: bool = False,
        in_reply_to: Optional[str] = None,
        references: Optional[str] = None,
    ) -> str:
        """Create RFC 2822 formatted message."""
        if attachments:
            message = MIMEMultipart()
        else:
            message = MIMEText(body, "html" if html else "plain")

        message["To"] = to
        message["Subject"] = subject

        if cc:
            message["Cc"] = cc
        if bcc:
            message["Bcc"] = bcc
        if in_reply_to:
            message["In-Reply-To"] = in_reply_to
        if references:
            message["References"] = references

        # Add body for multipart
        if attachments:
            message.attach(MIMEText(body, "html" if html else "plain"))

            # Add attachments
            for file_path in attachments:
                self._attach_file(message, file_path)

        # Encode message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        return raw_message

    def _attach_file(self, message: MIMEMultipart, file_path: str) -> None:
        """Attach file to message."""
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Attachment not found: {file_path}")

        content_type, _ = mimetypes.guess_type(file_path)

        if content_type is None:
            content_type = "application/octet-stream"

        main_type, sub_type = content_type.split("/", 1)

        with open(file_path, "rb") as f:
            if main_type == "text":
                attachment = MIMEText(f.read().decode(), _subtype=sub_type)
            elif main_type == "image":
                attachment = MIMEImage(f.read(), _subtype=sub_type)
            elif main_type == "audio":
                attachment = MIMEAudio(f.read(), _subtype=sub_type)
            else:
                attachment = MIMEBase(main_type, sub_type)
                attachment.set_payload(f.read())

        attachment.add_header("Content-Disposition", "attachment", filename=path.name)
        message.attach(attachment)

    def search_messages(self, query: str, max_results: int = 100, user_id: str = "me") -> List[Dict[str, Any]]:
        """
        Search messages (convenience method).

        Args:
            query: Gmail search query
            max_results: Maximum results
            user_id: User ID

        Returns:
            List of messages
        """
        result = self.list_messages(user_id=user_id, query=query, max_results=max_results)
        return result["messages"]

    # ============================================================================
    # HELPER METHODS (GWS-style convenience commands)
    # ============================================================================

    def triage_inbox(self, max_results: int = 20, user_id: str = "me") -> List[Dict[str, Any]]:
        """
        Show unread inbox summary (sender, subject, date).
        GWS-style helper command.

        Args:
            max_results: Maximum number of unread messages
            user_id: User ID

        Returns:
            List of message summaries with from, subject, date
        """
        result = self.list_messages(user_id=user_id, query="is:unread", max_results=max_results)
        messages = result["messages"]

        summaries = []
        for msg in messages:
            try:
                full_msg = self.get_message(msg["id"], format="metadata",
                                           metadata_headers=["From", "Subject", "Date"])
                headers = {h["name"]: h["value"] for h in full_msg.get("payload", {}).get("headers", [])}
                summaries.append({
                    "id": full_msg["id"],
                    "thread_id": full_msg.get("threadId"),
                    "from": headers.get("From", "N/A"),
                    "subject": headers.get("Subject", "(No subject)"),
                    "date": headers.get("Date", "N/A"),
                    "snippet": full_msg.get("snippet", "")
                })
            except Exception:
                continue

        return summaries

    def read_message_body(self, message_id: str, user_id: str = "me") -> Dict[str, Any]:
        """
        Read message and extract body (text and/or HTML).
        GWS-style helper command.

        Args:
            message_id: Message ID
            user_id: User ID

        Returns:
            Dict with headers and body content
        """
        message = self.get_message(message_id, user_id=user_id, format="full")

        headers = {h["name"]: h["value"] for h in message.get("payload", {}).get("headers", [])}

        # Extract body
        body_text = ""
        body_html = ""

        def extract_body(payload):
            nonlocal body_text, body_html

            if "parts" in payload:
                for part in payload["parts"]:
                    extract_body(part)
            elif "body" in payload and "data" in payload["body"]:
                mime_type = payload.get("mimeType", "")
                data = payload["body"]["data"]
                decoded = base64.urlsafe_b64decode(data).decode("utf-8", errors="ignore")

                if mime_type == "text/plain":
                    body_text = decoded
                elif mime_type == "text/html":
                    body_html = decoded

        extract_body(message.get("payload", {}))

        return {
            "id": message["id"],
            "thread_id": message.get("threadId"),
            "from": headers.get("From", "N/A"),
            "to": headers.get("To", "N/A"),
            "subject": headers.get("Subject", "(No subject)"),
            "date": headers.get("Date", "N/A"),
            "body_text": body_text,
            "body_html": body_html,
            "snippet": message.get("snippet", "")
        }

    def reply_to_message(
        self,
        message_id: str,
        body: str,
        user_id: str = "me",
        html: bool = False
    ) -> Dict[str, Any]:
        """
        Reply to a message (handles threading automatically).
        GWS-style helper command.

        Args:
            message_id: Original message ID
            body: Reply body
            user_id: User ID
            html: If True, send as HTML

        Returns:
            Sent message metadata
        """
        # Get original message to extract headers
        original = self.get_message(message_id, user_id=user_id, format="full")
        headers = {h["name"]: h["value"] for h in original.get("payload", {}).get("headers", [])}

        # Extract reply-to or from
        reply_to = headers.get("Reply-To", headers.get("From", ""))
        subject = headers.get("Subject", "")
        message_id_header = headers.get("Message-ID", "")

        # Add "Re:" if not present
        if not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"

        # Send reply with threading headers
        return self.send_message(
            to=reply_to,
            subject=subject,
            body=body,
            user_id=user_id,
            html=html,
            in_reply_to=message_id_header,
            references=message_id_header
        )

    def reply_all_to_message(
        self,
        message_id: str,
        body: str,
        user_id: str = "me",
        html: bool = False
    ) -> Dict[str, Any]:
        """
        Reply-all to a message (handles threading automatically).
        GWS-style helper command.

        Args:
            message_id: Original message ID
            body: Reply body
            user_id: User ID
            html: If True, send as HTML

        Returns:
            Sent message metadata
        """
        # Get original message
        original = self.get_message(message_id, user_id=user_id, format="full")
        headers = {h["name"]: h["value"] for h in original.get("payload", {}).get("headers", [])}

        # Extract recipients
        reply_to = headers.get("Reply-To", headers.get("From", ""))
        to = headers.get("To", "")
        cc = headers.get("Cc", "")
        subject = headers.get("Subject", "")
        message_id_header = headers.get("Message-ID", "")

        # Add "Re:" if not present
        if not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"

        # Combine recipients (exclude self)
        all_recipients = [reply_to]
        if to:
            all_recipients.extend([r.strip() for r in to.split(",")])

        # Get user's email to exclude from CC
        profile = self.execute_api_call(self.service.users().getProfile(userId=user_id))
        user_email = profile.get("emailAddress", "")

        # Filter CC list
        cc_list = []
        if cc:
            cc_list = [r.strip() for r in cc.split(",") if r.strip() != user_email]

        return self.send_message(
            to=reply_to,
            subject=subject,
            body=body,
            user_id=user_id,
            cc=",".join(cc_list) if cc_list else None,
            html=html,
            in_reply_to=message_id_header,
            references=message_id_header
        )

    def forward_message(
        self,
        message_id: str,
        to: str,
        body: Optional[str] = None,
        user_id: str = "me"
    ) -> Dict[str, Any]:
        """
        Forward a message to new recipients.
        GWS-style helper command.

        Args:
            message_id: Original message ID
            to: Recipient email(s)
            body: Optional message to prepend
            user_id: User ID

        Returns:
            Sent message metadata
        """
        # Get original message
        original_data = self.read_message_body(message_id, user_id=user_id)

        subject = original_data["subject"]
        if not subject.lower().startswith("fwd:"):
            subject = f"Fwd: {subject}"

        # Build forwarded message body
        forwarded_body = ""
        if body:
            forwarded_body = f"{body}\n\n"

        forwarded_body += f"---------- Forwarded message ---------\n"
        forwarded_body += f"From: {original_data['from']}\n"
        forwarded_body += f"Date: {original_data['date']}\n"
        forwarded_body += f"Subject: {original_data['subject']}\n"
        forwarded_body += f"To: {original_data['to']}\n\n"
        forwarded_body += original_data['body_text']

        return self.send_message(
            to=to,
            subject=subject,
            body=forwarded_body,
            user_id=user_id
        )
