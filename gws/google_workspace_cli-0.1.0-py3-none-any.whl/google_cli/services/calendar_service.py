"""Google Calendar service implementation."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from ..auth.scopes import ServiceScopes
from ..core.client import BaseClient
from ..core.errors import GoogleNotFoundError


class CalendarService(BaseClient):
    """Google Calendar operations."""

    def __init__(self, credentials_path: Optional[str] = None, readonly: bool = False):
        """
        Initialize Calendar service.

        Args:
            credentials_path: Path to credentials.json
            readonly: If True, use readonly scope
        """
        scope = ServiceScopes.CALENDAR_READONLY if readonly else ServiceScopes.CALENDAR

        super().__init__(
            service_name="calendar",
            version="v3",
            credentials_path=credentials_path,
            scopes=[scope.value],
        )

    # ============================================================================
    # CALENDAR OPERATIONS
    # ============================================================================

    def list_calendars(self) -> List[Dict[str, Any]]:
        """List user's calendars."""
        result = self.execute_api_call(self.service.calendarList().list())
        return result.get("items", [])

    def get_calendar(self, calendar_id: str) -> Dict[str, Any]:
        """Get calendar by ID."""
        try:
            return self.execute_api_call(
                self.service.calendars().get(calendarId=calendar_id)
            )
        except Exception:
            raise GoogleNotFoundError("Calendar", calendar_id)

    def create_calendar(self, summary: str, description: Optional[str] = None, timezone: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new calendar.

        Args:
            summary: Calendar name
            description: Calendar description
            timezone: Timezone (e.g., 'Asia/Seoul')

        Returns:
            Created calendar
        """
        body: Dict[str, Any] = {"summary": summary}

        if description:
            body["description"] = description
        if timezone:
            body["timeZone"] = timezone

        return self.execute_api_call(self.service.calendars().insert(body=body))

    def update_calendar(
        self, calendar_id: str, summary: Optional[str] = None, description: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update calendar properties."""
        body: Dict[str, Any] = {}

        if summary:
            body["summary"] = summary
        if description:
            body["description"] = description

        return self.execute_api_call(
            self.service.calendars().update(calendarId=calendar_id, body=body)
        )

    def delete_calendar(self, calendar_id: str) -> None:
        """Delete a calendar."""
        self.execute_api_call(self.service.calendars().delete(calendarId=calendar_id))

    def clear_calendar(self, calendar_id: str) -> None:
        """Clear all events from primary calendar."""
        self.execute_api_call(self.service.calendars().clear(calendarId=calendar_id))

    # ============================================================================
    # EVENT OPERATIONS
    # ============================================================================

    def list_events(
        self,
        calendar_id: str = "primary",
        time_min: Optional[str] = None,
        time_max: Optional[str] = None,
        query: Optional[str] = None,
        max_results: int = 250,
        order_by: Optional[str] = None,
        single_events: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        List calendar events.

        Args:
            calendar_id: Calendar ID or 'primary'
            time_min: Start time (ISO 8601)
            time_max: End time (ISO 8601)
            query: Search query
            max_results: Maximum results
            order_by: Sort order (startTime, updated)
            single_events: Expand recurring events

        Returns:
            List of events
        """
        params: Dict[str, Any] = {
            "calendarId": calendar_id,
            "maxResults": max_results,
            "singleEvents": single_events,
        }

        if time_min:
            params["timeMin"] = time_min
        if time_max:
            params["timeMax"] = time_max
        if query:
            params["q"] = query
        if order_by:
            params["orderBy"] = order_by

        result = self.execute_api_call(self.service.events().list(**params))
        return result.get("items", [])

    def get_event(self, event_id: str, calendar_id: str = "primary") -> Dict[str, Any]:
        """Get event by ID."""
        try:
            return self.execute_api_call(
                self.service.events().get(calendarId=calendar_id, eventId=event_id)
            )
        except Exception:
            raise GoogleNotFoundError("Event", event_id)

    def create_event(
        self,
        summary: str,
        start: str,
        end: str,
        calendar_id: str = "primary",
        description: Optional[str] = None,
        location: Optional[str] = None,
        attendees: Optional[List[str]] = None,
        recurrence: Optional[List[str]] = None,
        reminders: Optional[Dict[str, Any]] = None,
        send_notifications: bool = True,
    ) -> Dict[str, Any]:
        """
        Create a calendar event.

        Args:
            summary: Event title
            start: Start time (ISO 8601)
            end: End time (ISO 8601)
            calendar_id: Calendar ID
            description: Event description
            location: Event location
            attendees: List of attendee emails
            recurrence: Recurrence rules (RRULE format)
            reminders: Reminder settings
            send_notifications: Send notifications to attendees

        Returns:
            Created event
        """
        body: Dict[str, Any] = {
            "summary": summary,
            "start": {"dateTime": start, "timeZone": "UTC"},
            "end": {"dateTime": end, "timeZone": "UTC"},
        }

        if description:
            body["description"] = description
        if location:
            body["location"] = location
        if attendees:
            body["attendees"] = [{"email": email} for email in attendees]
        if recurrence:
            body["recurrence"] = recurrence
        if reminders:
            body["reminders"] = reminders

        return self.execute_api_call(
            self.service.events().insert(
                calendarId=calendar_id, body=body, sendNotifications=send_notifications
            )
        )

    def update_event(
        self,
        event_id: str,
        calendar_id: str = "primary",
        summary: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        send_notifications: bool = True,
    ) -> Dict[str, Any]:
        """Update an event."""
        # Get existing event
        event = self.get_event(event_id, calendar_id)

        # Update fields
        if summary:
            event["summary"] = summary
        if start:
            event["start"] = {"dateTime": start, "timeZone": "UTC"}
        if end:
            event["end"] = {"dateTime": end, "timeZone": "UTC"}
        if description:
            event["description"] = description
        if location:
            event["location"] = location

        return self.execute_api_call(
            self.service.events().update(
                calendarId=calendar_id,
                eventId=event_id,
                body=event,
                sendNotifications=send_notifications,
            )
        )

    def patch_event(
        self, event_id: str, updates: Dict[str, Any], calendar_id: str = "primary"
    ) -> Dict[str, Any]:
        """Partially update an event."""
        return self.execute_api_call(
            self.service.events().patch(calendarId=calendar_id, eventId=event_id, body=updates)
        )

    def delete_event(
        self, event_id: str, calendar_id: str = "primary", send_notifications: bool = True
    ) -> None:
        """Delete an event."""
        self.execute_api_call(
            self.service.events().delete(
                calendarId=calendar_id, eventId=event_id, sendNotifications=send_notifications
            )
        )

    def move_event(
        self, event_id: str, source_calendar_id: str, destination_calendar_id: str
    ) -> Dict[str, Any]:
        """Move event to another calendar."""
        return self.execute_api_call(
            self.service.events().move(
                calendarId=source_calendar_id,
                eventId=event_id,
                destination=destination_calendar_id,
            )
        )

    def quick_add(self, text: str, calendar_id: str = "primary") -> Dict[str, Any]:
        """
        Create event from text.

        Args:
            text: Natural language text (e.g., "Meeting tomorrow at 3pm")
            calendar_id: Calendar ID

        Returns:
            Created event
        """
        return self.execute_api_call(
            self.service.events().quickAdd(calendarId=calendar_id, text=text)
        )

    def get_recurring_instances(
        self,
        event_id: str,
        calendar_id: str = "primary",
        time_min: Optional[str] = None,
        time_max: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Get instances of a recurring event."""
        params: Dict[str, Any] = {"calendarId": calendar_id, "eventId": event_id}

        if time_min:
            params["timeMin"] = time_min
        if time_max:
            params["timeMax"] = time_max

        result = self.execute_api_call(self.service.events().instances(**params))
        return result.get("items", [])

    # ============================================================================
    # FREEBUSY OPERATIONS
    # ============================================================================

    def query_freebusy(
        self, calendars: List[str], time_min: str, time_max: str
    ) -> Dict[str, Any]:
        """
        Query free/busy information.

        Args:
            calendars: List of calendar IDs
            time_min: Start time (ISO 8601)
            time_max: End time (ISO 8601)

        Returns:
            Free/busy data for each calendar
        """
        body = {
            "timeMin": time_min,
            "timeMax": time_max,
            "items": [{"id": cal_id} for cal_id in calendars],
        }

        return self.execute_api_call(self.service.freebusy().query(body=body))
